import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headerShared',
  templateUrl: './headerShared.component.html',
  styleUrls: ['./headerShared.component.scss']
})
export class HeaderSharedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
