export const environment = {
  production: true,
  // apiUrl: "https://localhost:5001/api/",
  //baseUrl: "https://localhost:5001/api/"
  baseUrl: "http://41.38.117.2:889/api/"

};
