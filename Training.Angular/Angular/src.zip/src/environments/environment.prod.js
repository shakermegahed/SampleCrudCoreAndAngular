"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = void 0;
exports.environment = {
    production: true,
    apiUrl: "https://localhost:5001/api/",
};
//# sourceMappingURL=environment.prod.js.map