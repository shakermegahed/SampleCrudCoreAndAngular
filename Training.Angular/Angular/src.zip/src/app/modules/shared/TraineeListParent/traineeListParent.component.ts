import { LookupDto } from './../../../models/Common/WorkPlaceDTO';
import { DeleteTrainee } from '../../../models/Admin/DeleteTrainee';
import { ConfirmationService, LazyLoadEvent, MessageService } from 'primeng/api';
import { ReviewTraineesDTO } from '../../../models/Admin/ReviewTraineesDTO';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ReviewTraineesFilter } from 'src/app/models/Admin/ReviewTraineesFilter';
import { ReviewTraineesService } from 'src/app/Services/Admin/review-trainees.service';
import { Subscription } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-traineeListParent',
  templateUrl: './traineeListParent.component.html',
  styleUrls: ['./traineeListParent.component.css'],
  providers: [MessageService, ConfirmationService]

})
export class TraineeListParentComponent implements OnInit {
  @ViewChild("closeModal") closeModal;
  formSubmitted: boolean = false;
  displayModalTrainee: boolean;
  TraineeTiltle: string;
  tranieeId: number;
  tranieename: string;
  loadingSpinner: boolean = false;
  formid: any;
  position: string;
  btnsave = false;
  btnedit = false;
  displayReason = false;
  displayModal = false;
  displayModalActiveInActive = false;
  selectedIdForDelete: number;
  selectedIdForActivate: number;
  emailInputValue = "";
  translation_words: any = [];
  Showingpagination: string;
  TOpagination: string;
  Ofpagination: string;
  Entriespagination: string;
  ShowSourceTypeDropDown: boolean = true;
  ShowWorkText: boolean = false;
  elements: ReviewTraineesDTO[];
  totalRecords: number = 0;
  loading: boolean = true;

  workPlaces: LookupDto[] = [];
  positions: LookupDto[] = [];

  firstName: string;
  secondName: string;
  thirdName: string;
  lastName: string;

  get FacultyErrors() {
    return this.TraineeForm.controls;
  }
  TraineeForm: FormGroup = new FormGroup({});
  TraineeFormForActivate: FormGroup;
  TraineeFormForSearch: FormGroup;
  submitted: false;
  filter: ReviewTraineesFilter = new ReviewTraineesFilter();
  constructor(
    private myservice: ReviewTraineesService,
    private translate: TranslateService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService
  ) {
    this.Showingpagination = 'General.Showing';
    this.TOpagination = 'General.to';
    this.Ofpagination = 'General.of';
    this.Entriespagination = 'General.entries';
    // this.titleService.setTitle("Student Registration");
    //  Get Translated Text
    translate.get(["Yes", "No", "DeleteConfirmation"]).subscribe((values) => {
      console.log('Loaded values', values);
      this.translation_words = {
        ConfirmationText: values.DeleteConfirmation,
        ConfirmationYes: values.No,
        ConfirmationNo: values.Yes
      }
    });
  }

  // search form inputs
  subscriptionb: Subscription;

  ngOnInit(): void {

    this.TraineeForm = new FormGroup({
      //remove
      // fullName: new FormControl("", Validators.required),

      firstName: new FormControl("", Validators.required),
      secondName: new FormControl("", Validators.required),
      thirdName: new FormControl("", Validators.required),
      lastName: new FormControl("", Validators.required),
      gender: new FormControl("", Validators.required),
      ssNumber: new FormControl("", [Validators.required, Validators.pattern("^(1|2)[0-9]{9}$")]),
      Email: new FormControl("", [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      userName: new FormControl("", Validators.required),
      workplaceType: new FormControl("", Validators.required),
      workplaceId: new FormControl(""),
      workPlaceText: new FormControl(""),
      status: new FormControl("", Validators.required),
      department: new FormControl(null),
      titleId: new FormControl('', Validators.required),
      birthDate: new FormControl("", Validators.required),
      phoneNumber: new FormControl("", [Validators.required, Validators.pattern("^(05)([0-9]{8})$")]),
      tranieeId: new FormControl(""),
    });

    this.TraineeFormForActivate = new FormGroup({
      tranieeId: new FormControl(""),

      // fullName: new FormControl("", Validators.required),


      status: new FormControl("", Validators.required),
      reason: new FormControl("", Validators.required)
    });

    this.TraineeFormForSearch = new FormGroup({

      fullName: new FormControl("", Validators.required),
      email: new FormControl("", Validators.required),
      ssNumber: new FormControl("", Validators.required),
      pageIndex: new FormControl("", Validators.required),
      pageSize: new FormControl("", Validators.required)

    });

    //this.GetTraineesData();

    this.myservice.GetWorkPlaces().subscribe(result => {
      this.workPlaces = result.list;
    })

    this.myservice.GetTraineesTitles().subscribe(result => {
      this.positions = result.list;
    })
  }

  get f() {
    return this.TraineeForm.controls;
  }

  onSubmit() {
    this.loadingSpinner = true;

    console.log("hi ", this.TraineeForm.get('ssNumber').errors);
    if (this.TraineeForm.invalid) {
      this.formSubmitted = true;
      return;
    }

    this.TraineeForm.value.HostName = this.GetUrl();
    this.formSubmitted = true;
    this.subscriptionb = this.myservice
      .AddTraniee(this.TraineeForm.value)
      .subscribe(
        (result) => {
          if (result.success) {
            this.messageService.add({
              severity: "success",
              summary: this.translate.instant('Success'),
              detail: result.message,
            });

            this.displayModalTrainee = false;
            this.GetTraineesData();
            this.onReset();
            this.loadingSpinner = false;

          }
          else {
            this.messageService.add({
              severity: "error",
              summary: this.translate.instant('Error'),
              detail: result.message,
            });
            this.loadingSpinner = false;
            this.displayModalTrainee = true;
          }
          this.closeModal.nativeElement.click();
          this.GetTraineesData();
          this.onReset();



          //console.log("Add Traniee ", res);
        },
        (err) => {
          //...
          this.loadingSpinner = false;

        }
      );
  }

  onSubmitedit() {
    this.loadingSpinner = true;

    if (this.TraineeForm.invalid) {
      this.formSubmitted = true;
      return;
    }
    this.subscriptionb = this.subscriptionb = this.myservice
      .UpdateTraniee(this.TraineeForm.value).subscribe((result) => {



        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
          this.loadingSpinner = false;
          this.displayModalTrainee = false;


          this.GetTraineesData();
          this.onReset();
        }
        else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
          this.loadingSpinner = false;
          this.displayModalTrainee = true;
        }

        this.closeModal.nativeElement.click();
        this.GetTraineesData();
        this.onReset();


        //console.log(" Update Traniee ", res);
      },
        (err) => {
          //...
        }
      );
  }

  onReset() {
    this.TraineeForm.reset();
  }

  ngOnDestroy(): void {
    //this.subscriptionb.unsubscribe();
  }

  askConfirmActivate(model: ReviewTraineesDTO) {
    this.loadingSpinner = true;

    console.log("hi ");
    this.displayModalActiveInActive = true;
    this.selectedIdForActivate = model.tranieeId;
    this.myservice.GetTranieeStatus(this.selectedIdForActivate).subscribe(result => {
      this.loadingSpinner = false;

      this.TraineeFormForActivate.patchValue({
        // fullName: result.firstName + result.secondName + result.thirdName + result.lastName,
        status: result.status
      })
      this.firstName = model.firstName;
      this.secondName = model.secondName;
      this.thirdName = model.thirdName;
      this.lastName = model.lastName;
    })
  }

  toggleModal(value) {
    this.displayModalActiveInActive = value;
    this.displayModal = value;


  }

  loadCustomers(event: LazyLoadEvent) {
    this.loading = true;
    const filter: ReviewTraineesFilter = new ReviewTraineesFilter();
    filter.pageIndex = event.first / event.rows;
    filter.pageSize = event.rows;
    this.myservice.GetTrainees(filter).subscribe(result => {
      this.elements = result.list;
      this.loading = false;
      this.totalRecords = result.resultPaging.recordsFiltered;
    })
  }

  DeleteTrainee() {
    this.loadingSpinner = true;

    let DeleteGovernment: DeleteTrainee = {
      IsDeleted: true,
      TranieeId: this.selectedIdForDelete,

    };

    this.myservice
      .DeleteUnDeleteTraniee(DeleteGovernment)
      .subscribe((result) => {
        this.loadingSpinner = false;

        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
          this.displayModal = false;
          this.GetTraineesData();
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
          this.displayModal = true;

        }

      });
  }


  askConfirmDelete(model: ReviewTraineesDTO) {
    console.log(
      "askConfirmDelete",
      (this.selectedIdForDelete = model.tranieeId,
        this.tranieename = model.firstName + model.lastName + model.thirdName + model.lastName
      )
    );

    this.displayModal = true;

    this.selectedIdForDelete = model.tranieeId;
    this.tranieename = model.firstName + ' ' + model.lastName + ' ' + model.thirdName + ' ' + model.lastName;

  }






  // DeleteTrainee() {
  //   let traineForDelete: DeleteTrainee = {
  //     IsDeleted: true,
  //     TranieeId: this.selectedIdForDelete,
  //   };
  //   // traineForDelete.IsDeleted = true;
  //   // traineForDelete.TranieeId = this.selectedIdForDelete;
  //   this.subscriptionb = this.myservice.DeleteUnDeleteTraniee(traineForDelete).subscribe((result) => {
  //       if (result.success) {
  //         this.messageService.add({
  //           severity: "success",
  //           summary: "Success",
  //           detail: result.message,
  //         });
  //       } else {
  //         this.messageService.add({
  //           severity: "error",
  //           summary: "Error",
  //           detail: result.message,
  //         });
  //       }
  //       this.displayModal = false;
  //       this.GetTraineesData();
  //     });
  // }

  ActivateDeatcivateTrainee() {

    this.loadingSpinner = true;
    this.displayModalActiveInActive = true;


    this.TraineeFormForActivate.patchValue({
      tranieeId: this.selectedIdForActivate
    });
    this.subscriptionb = this.myservice
      .ActiveTraniee(this.TraineeFormForActivate.value)
      .subscribe((result) => {
        this.loadingSpinner = false;

        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,

          });

        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }
        this.displayModalActiveInActive = false;
        this.TraineeFormForActivate.reset();
        this.GetTraineesData();
      }, err => {
        this.loadingSpinner = false;

      });
  }

  GetTraineesData() {
    this.loadingSpinner = true;
    this.TraineeFormForSearch.patchValue({
      pageIndex: 0,
      pageSize: 10
    })
    // this.filter.pageIndex = 10;
    // this.filter.pagelength = 0;
    this.subscriptionb = this.myservice
      .GetTrainees(this.TraineeFormForSearch.value)
      .subscribe((resp) => {
        this.loadingSpinner = false;
        this.elements = resp.list;
        //this.totalRecords = resp.length;
        this.totalRecords = resp.resultPaging.recordsFiltered;
        console.log(resp);
      });
  }

  viewmodeledit(tranieeId) {
    this.displayModalTrainee = true;

    this.loadingSpinner = true;

    this.TraineeTiltle = "Trainee.Modifytraineedata";

    this.TraineeForm.enable();
    this.TraineeForm.addControl(
      "tranieeId",
      new FormControl("", Validators.required)
    );

    this.TraineeForm.controls.status.disable();

    this.btnsave = false;
    this.btnedit = true;
    console.log("edit:", tranieeId);

    this.subscriptionb = this.myservice
      .GetTranieeById(tranieeId)
      .subscribe((resp) => {
        this.loadingSpinner = false;

        this.TraineeForm.patchValue({
          firstName: resp.firstName,
          secondName: resp.secondName,
          thirdName: resp.thirdName,
          lastName: resp.lastName,
          // fullName: resp.fullName,
          gender: resp.gender,
          ssNumber: resp.ssNumber,
          Email: resp.email,
          userName: resp.userName,
          status: resp.status,
          department: resp.department,
          workplaceType: resp.workplaceType == "3" ? 1 : resp.workplaceType,
          workplaceId: resp.workplaceType == "3" ? "0" : resp.workplaceId,
          workPlaceText: resp.workPlaceText,
          titleId: resp.titleId,
          birthDate: resp.birthDate,
          phoneNumber: resp.phoneNumber,
          tranieeId: resp.tranieeId,
        });
        if (resp.workplaceType == "1" || resp.workplaceType == "3") {
          this.ShowSourceTypeDropDown = true;
        }
        else {
          this.ShowSourceTypeDropDown = false;
        }
        if (resp.workplaceType == "3") {
          this.ShowWorkText = true;
        }
        else {
          this.ShowWorkText = false;
        }
        console.log(resp);
      });
  }


  viewmodelView(tranieeId) {
    this.displayModalTrainee = true;

    this.loadingSpinner = true;

    this.TraineeTiltle = "Trainee.Reviewtraineedata";
    this.btnsave = false;
    this.btnedit = false;
    this.TraineeForm.addControl(
      "tranieeId",
      new FormControl("", Validators.required)
    );

    this.TraineeForm.disable();
    this.subscriptionb = this.myservice
      .GetTranieeById(tranieeId)
      .subscribe((resp) => {
        this.loadingSpinner = false;

        this.TraineeForm.patchValue({

          firstName: resp.firstName,
          secondName: resp.secondName,
          thirdName: resp.thirdName,
          lastName: resp.lastName,
          // fullName: resp.fullName,
          gender: resp.gender,
          ssNumber: resp.ssNumber,
          Email: resp.email,
          userName: resp.userName,
          status: resp.status,
          department: resp.department,
          workplaceType: resp.workplaceType == "3" ? 1 : resp.workplaceType,
          workplaceId: resp.workplaceType == "3" ? "0" : resp.workplaceId,
          workPlaceText: resp.workPlaceText,
          titleId: resp.titleId,
          birthDate: resp.birthDate,
          phoneNumber: resp.phoneNumber,
          tranieeId: resp.tranieeId,
        });
        if (resp.workplaceType == "1" || resp.workplaceType == "3") {
          this.ShowSourceTypeDropDown = true;
        }
        else {
          this.ShowSourceTypeDropDown = false;
        }
        if (resp.workplaceType == "3") {
          this.ShowWorkText = true;
        }
        else {
          this.ShowWorkText = false;
        }
        console.log(resp);
      });
  }

  OpenModelAdd() {
    this.formSubmitted = false;
    this.displayModalTrainee = true;
    this.TraineeTiltle = "Addtrainee";
    this.TraineeForm.enable();
    this.onReset();
    this.TraineeForm.removeControl("tranieeId");

    this.btnsave = true;
    this.btnedit = false;
  }

  onCheckboxChange(e) {
    console.log("hi from change ", e.target.checked)
    if (e.target.checked) {
      this.displayReason = false;
    }
    else {
      this.displayReason = true;
    }
  }

  onChangeWorkType(event: any) {
    console.log("hii this is selected", event.target.value);
    if (event.target.value == 1) {
      this.ShowSourceTypeDropDown = true;
    }
    else {
      this.ShowSourceTypeDropDown = false;
    }
  }

  onChangeWorkPlaceId(event: any) {
    if (event.target.value == 0) {
      this.ShowWorkText = true;
    }
    else {
      this.ShowWorkText = false;
    }
  }

  SearchTrainee() {
    this.GetTraineesData();
  }

  GetUrl() {
    var url = window.location.href
    var arr = url.split("/");
    return arr[0] + "//" + arr[2];
  }
  setUserName(val) {
    if (this.btnsave) {
      this.TraineeForm.controls['userName'].setValue(val);
    }
  }



}
