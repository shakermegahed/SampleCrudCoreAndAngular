import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-headerShared',
  templateUrl: './headerShared.component.html',
  styleUrls: ['./headerShared.component.scss']
})
export class HeaderSharedComponent implements OnInit {

  @Input() pageType:string;
  constructor() { }

  ngOnInit() {
  

  }



  getUserName() {
   
      return localStorage.getItem('name');
  
  }
  
  getUserRole() {
    return localStorage.getItem('userRoles');
  }


}
