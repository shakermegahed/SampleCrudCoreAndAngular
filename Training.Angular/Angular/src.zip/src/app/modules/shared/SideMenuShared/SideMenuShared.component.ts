import { LookupDto } from './../../../models/Common/WorkPlaceDTO';
import { Component, Input, OnInit } from '@angular/core';
import { NavMenu } from 'src/app/models/Common/NavMenuItem';

@Component({
  selector: 'app-SideMenuShared',
  templateUrl: './SideMenuShared.component.html',
  styleUrls: ['./SideMenuShared.component.scss']
})
export class SideMenuSharedComponent implements OnInit {

  @Input() navItem: NavMenu[];
  lookups: LookupDto[] = []
  // {
  //   path     : "/rvrgstr",
  //   icon     : "mdi mdi-chart-pie",
  //   linkTitle: "الرئيسية",
  // },
  // {
  //   path     : "/rvrgstr/GovernmentalEntities",

  //   icon     : "mdi mdi-view-dashboard",
  //   linkTitle: "ادارة الجهات الحكومية",
  // },

  // {
  //   path     : "/rvrgstr/Trainee",
  //   icon     : "mdi mdi-account-multiple",
  //   linkTitle: "ادارة المتدربين",
  // },
  // {
  //   path     : "/rvrgstr",
  //   icon     : "mdi mdi-content-paste",
  //   linkTitle: "ادارة الدورات التدريبية"
  // },
  // {
  //   path     : "/",
  //   icon     : "mdi mdi-account-multiple",
  //   linkTitle: "تسجيل خروج"
  // }
  //];
  @Input() fff: string = "asd";
  //   {
  //     path     : "/rvrgstr",
  //     icon     : "mdi mdi-chart-pie",
  //     linkTitle: "الرئيسية",
  //   },
  //   {
  //     path     : "/rvrgstr/GovernmentalEntities",

  //     icon     : "mdi mdi-view-dashboard",
  //     linkTitle: "ادارة الجهات الحكومية",
  //   },

  //   {
  //     path     : "/rvrgstr/Trainee",
  //     icon     : "mdi mdi-account-multiple",
  //     linkTitle: "ادارة المتدربين",
  //   },
  //   {
  //     path     : "/rvrgstr",
  //     icon     : "mdi mdi-content-paste",
  //     linkTitle: "ادارة الدورات التدريبية"
  //   },
  //   {
  //     path     : "/",
  //     icon     : "mdi mdi-account-multiple",
  //     linkTitle: "تسجيل خروج"
  //   },
  // ];
  toggleCollapseChild(Elm) {
    try {
      if (Elm.closest("a").nextSibling.classList) {
        Elm.closest("a").nextSibling.classList.toggle("collapse")
      }
    } catch (err) {

    }
  }
  constructor() { }
  
  ngOnInit() {
    // let newitem:NavMenu = new NavMenu();
    // newitem.path="";
    // newitem.icon="";
    // newitem.linkTitle="الرئيسية من هنا";

    //  this.navItem.push(newitem);
    //this.lookups.
    //this.navItem.
    console.log("this is Shared Nav page for admin ", this.navItem);
    console.log("this is Shared Nav page for admin ", this.lookups);
  }

}
