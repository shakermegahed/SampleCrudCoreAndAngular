import { Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { LookupDto } from './../../../../models/Common/WorkPlaceDTO';
import { DeleteCancelCourse } from './../../../../models/Courses/DeleteCancelCourse';
import { ReviewCoursesService } from './../../../../Services/Courses/review-courses.service';
import { ReviewCoursesFilter } from './../../../../models/Courses/ReviewCoursesFilter';
import { ConfirmationService, LazyLoadEvent, MessageService } from 'primeng/api';
import { Course } from './../../../../models/Courses/Course';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { Lookup } from 'src/app/models/Common/lookup';

@Component({
  selector: 'app-viewcoursesShared',
  templateUrl: './viewcourses.component.html',
  styleUrls: ['./viewcourses.component.css'],
  providers: [MessageService, ConfirmationService]

})
export class ViewcoursesSharedComponent implements OnInit {
  Showingpagination: string;
  TOpagination: string;
  Ofpagination: string;
  Entriespagination: string;
  CourseFormForSearch: FormGroup;

  courseTypes:LookupDto[] = [];
  courseStatus:LookupDto[] = [];
  selectedIdForCancel:number;
  displayModal = false;
  courseName:string;
  elements: Course[];
  totalRecords: number = 0;
  formSubmitted: boolean = false;
  loading: boolean = true;
  loadingSpinner: boolean = false;



  constructor(private courseService:ReviewCoursesService,private router: Router,
    private messageService: MessageService,
    private translate: TranslateService

    ) {

      this.Showingpagination = 'General.Showing';
      this.TOpagination = 'General.to';
      this.Ofpagination = 'General.of';
      this.Entriespagination = 'General.entries';

    }

    subscriptionb: Subscription;


  ngOnInit() {

    this.CourseFormForSearch = new FormGroup({

      Year: new FormControl("", Validators.required),
      CourseTypeId: new FormControl("", Validators.required),
      CourseStatusId: new FormControl("", Validators.required),
      courseName: new FormControl("", Validators.required)

    });

    this.courseService.GetCourseTypes().subscribe(result=>{
      this.courseTypes = result.list
    });
    this.courseService.GetCourseStatus().subscribe(result=>{
      this.courseStatus = result.list
    });

  }

  loadCourses(event: LazyLoadEvent) {
    this.loading = true;
    const filter: ReviewCoursesFilter = new ReviewCoursesFilter();
    filter.pageIndex = event.first / event.rows;
    filter.pageSize = event.rows;
    this.courseService.GetCourses(filter).subscribe(result => {
      this.elements = result.list;
      this.loading = false;
      this.totalRecords = result.resultPaging.recordsFiltered;
    })
  }

  GetCoursesData() {
    this.loadingSpinner = true;
     this.CourseFormForSearch.patchValue({
      pageIndex: 0,
      pageSize: 10
    })
    // this.filter.pageIndex = 10;
    // this.filter.pagelength = 0;
    this.subscriptionb = this.courseService
      .GetCourses(this.CourseFormForSearch.value)
      .subscribe((resp) => {
        this.loadingSpinner = false;
        this.elements = resp.list;
        //this.totalRecords = resp.length;
        this.totalRecords = resp.resultPaging.recordsFiltered;
        console.log(resp);
      });
  }

  OpenManageCourses(){
    this.router.navigate(["/rvrgstr", "AddCourses"]);
  }

  OpenGetCoursesById(id: number) {
    this.router.navigate(["/rvrgstr/GetCoursesById/", id]);
  }

  EditCourse(id: number) {
    this.router.navigate(["/rvrgstr/EditCourses/", id]);
  }

  askConfirmCancel(model: Course) {


    this.displayModal = true;

    this.selectedIdForCancel = model.id;
    this.courseName = model.courseName;

  }

  CancelCourse() {
    this.loadingSpinner = true;

    let DeleteCancelCourse: DeleteCancelCourse = {
      IsDeleted: true,
      courseId: this.selectedIdForCancel,
      reason :""

    };

    this.courseService
      .CancelCourse(DeleteCancelCourse)
      .subscribe((result) => {
        this.loadingSpinner = false;

        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
          this.displayModal = false;
          this.GetCoursesData();
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
          this.displayModal = true;

        }

      });
  }

  toggleModal(value) {
    this.displayModal = value;


  }

  SearchCourse(){
    this.GetCoursesData();
  }

}
