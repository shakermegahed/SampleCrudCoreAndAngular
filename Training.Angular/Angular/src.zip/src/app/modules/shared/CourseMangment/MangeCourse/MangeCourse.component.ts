import { HttpClient } from "@angular/common/http";
import { FormArray, FormControl, FormGroup, Validators } from "@angular/forms";
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Title } from "@angular/platform-browser";
import { TranslateService } from "@ngx-translate/core";
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { LazyLoadEvent, MessageService } from "primeng/api";
import { ActivatedRoute } from "@angular/router";
import { Router } from "@angular/router";

import { Subscription } from "rxjs";
import { ReviewCoursesService } from "../../../../Services/Courses/review-courses.service";
import { TrainerService } from "../../../../Services/Trainer/trainer.service";
import { CityService } from "../../../../Services/City/city.service";
import { LookupDto } from "../../../../models/Common/WorkPlaceDTO";
import { ReviewTrainerFilter } from "../../../../models/Trainer/ReviewTrainerFilter";
import { CourseExtraSetting } from "../../../../models/Courses/CourseExtraSetting";
import { CourseExtraSettingImplement } from "../../../../models/Courses/CourseExtraSettingImplment";
import * as $ from 'jquery';

@Component({
  selector: 'app-MangeCourse',
  templateUrl: './MangeCourse.component.html',
  styleUrls: ['./MangeCourse.component.css'],
  providers: [MessageService],
})
export class MangeCourseComponent implements OnInit {
  @ViewChild("SaveBtn") SaveBtn;
  @ViewChild("EditBtn") EditBtn;
  btnsave = false;
  btnedit = false;
  CourseForm: FormGroup = new FormGroup({});
  TrinerFormFitler: FormGroup = new FormGroup({});
  Trainers: LookupDto[] = [];
  Cities: LookupDto[] = [];
  CourseTypes: LookupDto[] = [];
  CourseStatus: LookupDto[] = [];
  DatesList: Date[] = [];
  subscriptionb: Subscription;
  CourseInitialValues: any;
  CourseDays: number = 0;
  ApiCount: number = 0;
  ThisId: string = "0";
  ThisUrl: string = "";
  courseTypeIdReadOnly: boolean = false
  constructor(private CourseService: ReviewCoursesService, private TrainerService: TrainerService,
    private CitiesService: CityService,
    private messageService: MessageService,
    private route: ActivatedRoute,
    private router: Router,
    private cdRef: ChangeDetectorRef ) {
  }

  get FacultyErrors() {
    return this.CourseForm.controls;
  }

  ngOnInit(): void {
    this.btnsave = false;
    this.btnedit = false;

    if (this.router.url.startsWith("/rvrgstr/AddCourses")) {
      this.ThisUrl = "Add";
      this.btnsave = true;
    } else if (this.router.url.startsWith("/rvrgstr/EditCourses")) {
      this.ThisUrl = "Edit";
    } else if (this.router.url.startsWith("/rvrgstr/GetCoursesById")) {
      this.ThisUrl = "ById";
    }

    this.CourseForm = new FormGroup({
     // number: new FormControl("", Validators.required),
      courseName: new FormControl("", Validators.required),
      courseTypeId: new FormControl("", Validators.required),
      //courseStatusId: new FormControl("", Validators.required),
      startDate: new FormControl("", Validators.required),
      endDate: new FormControl("", Validators.required),
      cityId: new FormControl("", Validators.required),
      isFree: new FormControl(false),
      fees: new FormControl(""),
      trainerName: new FormControl(""),
      address: new FormControl("", Validators.required),
      avaliableSeats: new FormControl("", Validators.required),
      numberWaitingSeats: new FormControl("", Validators.required),
      //numberOfDays: new FormControl("", Validators.required),
      isEvaluationEnabled: new FormControl(false),
      highestScore: new FormControl("", Validators.required),
      minimumSuccessScore: new FormControl("", Validators.required),
      miminumAttendance: new FormControl("", Validators.required),
      //extraSetting: new FormGroup({
      schoolCertificate: new FormControl(false),
      jobDescription: new FormControl(false),
      saudiPostalCode: new FormControl(false),
      buildingNumber: new FormControl(false),
      streetNumber: new FormControl(false),
      postalCode: new FormControl(false),
      extraCode: new FormControl(false),
      fillExcelForProfessionalCourse: new FormControl(false),
      fillWordForProfessionalCourse: new FormControl(false),
      fillEnergyForm: new FormControl(false),
      approvalLetter: new FormControl(false),
      canLeave: new FormControl(false),
      canChangeDate: new FormControl(false),
      canLeaveAndMoneyBack: new FormControl(false),
      canRedoTest: new FormControl(false),
      canChangeTestDate: new FormControl(false),
      canRegisterInWaitingList: new FormControl(false),
      hasCourseCertificate: new FormControl(false),
      isExtraCourse: new FormControl(false)
      //})
    });

    this.CourseInitialValues = this.CourseForm.value;

    this.TrinerFormFitler.patchValue({
      pageIndex: 0,
      pageSize: 0
    })
    
    this.ApiCount = 0;
    //this.TrainerService.GetTrainers(this.TrinerFormFitler.value).subscribe(result => {
    //  this.Trainers = result.list;
    //  this.ApiCount += 1;
    //})
    this.CitiesService.GetCities().subscribe(result => {
      this.Cities = result.list;
      this.ApiCount += 1;
    })
    this.CourseService.GetCourseTypes().subscribe(result => {
      this.CourseTypes = result.list;
      this.ApiCount += 1;
    })
    this.CourseService.GetCourseStatus().subscribe(result => {
      this.CourseStatus = result.list;
      this.ApiCount += 1;
    })
  
    if (this.ThisUrl!="Add") {
      this.ThisId = this.route.snapshot.paramMap.get('id');
      this.GetCourseById(this.ThisId);
      if (this.ThisUrl == "Edit") {
        this.CourseForm.controls["courseTypeId"].disable();
      }
    }
  }

  onSubmit() {
    this.ValidateSeatsAndMarks();
    if (this.CourseForm.valid) {
        this.SaveBtn.nativeElement.disabled = true;
        this.CourseForm.value.dates = this.DatesList;
        this.CourseForm.value.extraSetting = this.GetExtraSettingObj();

        this.subscriptionb = this.CourseService
          .AddCourse(this.CourseForm.value)
          .subscribe(
            (result) => {
              if (result.success) {
                this.messageService.add({
                  severity: "success",
                  summary: "Success",
                  detail: result.message,
                });
                this.onExit();
                this.SaveBtn.nativeElement.disabled = false;
              }
              else {
                this.messageService.add({
                  severity: "error",
                  summary: "Error",
                  detail: result.message,
                });
                this.SaveBtn.nativeElement.disabled = false;

              }

              //console.log("Add Traniee ", res);
            },
            (err) => {
              //...
            }
          );
    } else {
      this.CourseForm.markAllAsTouched();
      this.SaveBtn.nativeElement.disabled = false;

      const invalid = [];
      const controls = this.CourseForm.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        console.log(name);
      }
    }
    }

  }

  private isValidDate(ThisDate:Date) {
    //let InputDate: string[] = [];
    let Valid = true;
    let DateFrom = this.CourseForm.controls["startDate"].value;
    let DateTo = this.CourseForm.controls["endDate"].value;
    if (!this.CheckDatesBetween(DateFrom, DateTo, ThisDate)) {
      return false;
    } else {
      return true;
    }
  }

  onSubmitEdit() {
    this.ValidateSeatsAndMarks();

    if (this.CourseForm.valid) {
        this.EditBtn.nativeElement.disabled = true;
        this.CourseForm.value.dates = this.DatesList;
        this.CourseForm.value.id = this.ThisId;
        this.CourseForm.value.extraSetting = this.GetExtraSettingObj();
        this.CourseForm.value.courseTypeId = this.CourseForm.controls["courseTypeId"].value;
        this.subscriptionb = this.CourseService
          .UpdateCourse(this.CourseForm.value).subscribe((result) => {
            if (result.success) {
              this.messageService.add({
                severity: "success",
                summary: "Success",
                detail: result.message,
              });
              this.onExit();
            }
            else {
              this.messageService.add({
                severity: "error",
                summary: "Error",
                detail: result.message,
              });
            }
            this.EditBtn.nativeElement.disabled = false;
            //console.log(" Update Traniee ", res);
          },
            (err) => {
              //...
            }
          );
    } else {
      this.CourseForm.markAllAsTouched();
      this.EditBtn.nativeElement.disabled = false;
    }
  }

  onReset() {
    this.CourseForm.reset(this.CourseInitialValues);
    let _this = this;
    document.querySelectorAll(".DateInput").forEach(function (elm) {
      _this.RemoveDay(<HTMLInputElement>elm)
    });
  }
  AddDay() {
    $(".DateRangeHide").addClass("hide");
    let ThisDate: Date = new Date($(".DateInput").val().toString());
    if (this.isValidDate(ThisDate)) {
      $(".DateInput").val("");
      $(".DatesRow").append("<tr><td class='d-flex justify-content-between align-items-center'>" + ThisDate.toLocaleDateString('fr-CA')+ "<button class='btn btn-danger RemoveBtn' (click)='RemoveDay($event.target)'><i class='fas fa-times'></i></button></td></tr>");

      let _this = this;
      document.querySelectorAll(".RemoveBtn").forEach(function (ThisElm) {
        if (!$(ThisElm).hasClass("Bound")) {
          ThisElm.addEventListener('click', function () {
            _this.RemoveDay(this)
          });
          $(ThisElm).addClass("Bound")
        }
      })

      this.DatesList.push(ThisDate);
      this.UpdateCount();
    } else {
      $(".DateRangeHide").removeClass("hide");
    }
  }
  RemoveDay(Elm) {
    let Index = $(Elm).index();
    $(Elm).parents("tr").remove();
    this.DatesList.splice(Index, 1);
    this.UpdateCount();
  }
  UpdateCount() {
    this.CourseDays = this.DatesList.length;
  }
  whichChild(elem) {
    var i = 0;
    while ((elem = elem.previousSibling) != null) ++i;
    return i;
  }
  GetCourseById(CourseId) {
    this.subscriptionb = this.CourseService
      .GetCourseById(CourseId)
      .subscribe((resp) => {
        let _this = this;
        let SetFormInt = setInterval(function () {
          if (_this.ApiCount == 3) {
            _this.SetFormValues(resp);
            clearInterval(SetFormInt);
            _this.SetDaysDate(resp.dates)
          }
        }, 500)
        console.log(resp);
      });
  }
  SetFormValues(resp) {
    if (resp.cityId == 0) {
      resp.cityId = null;
    }
    this.CourseForm.patchValue({
     // number: resp.number,
      courseName: resp.courseName,
      courseTypeId: resp.courseTypeId,
      startDate: resp.startDate,
      endDate: resp.endDate,
      cityId: resp.cityId,
      isFree: resp.isFree,
      fees: resp.fees,
      trainerName: resp.trainerName,
      address: resp.address,
      avaliableSeats: resp.avaliableSeats,
      numberWaitingSeats: resp.numberWaitingSeats,
      isEvaluationEnabled: resp.isEvaluationEnabled,
      highestScore: resp.highestScore,
      minimumSuccessScore: resp.minimumSuccessScore,
      miminumAttendance: resp.miminumAttendance,
      hasCourseCertificate: resp.hasCourseCertificate,
      isExtraCourse: resp.isExtraCourse,
      schoolCertificate: resp.extraSetting.schoolCertificate,
      jobDescription: resp.extraSetting.jobDescription,
      saudiPostalCode: resp.extraSetting.saudiPostalCode,
      buildingNumber: resp.extraSetting.buildingNumber,
      streetNumber: resp.extraSetting.streetNumber,
      postalCode: resp.extraSetting.postalCode,
      extraCode: resp.extraSetting.extraCode,
      fillExcelForProfessionalCourse: resp.extraSetting.fillExcelForProfessionalCourse,
      fillWordForProfessionalCourse: resp.extraSetting.fillWordForProfessionalCourse,
      fillEnergyForm: resp.extraSetting.fillEnergyForm,
      approvalLetter: resp.extraSetting.approvalLetter,
      canLeave: resp.extraSetting.canLeave,
      canChangeDate: resp.extraSetting.canChangeDate,
      canLeaveAndMoneyBack: resp.extraSetting.canLeaveAndMoneyBack,
      canRedoTest: resp.extraSetting.canRedoTest,
      canChangeTestDate: resp.extraSetting.canChangeTestDate,
      canRegisterInWaitingList: resp.extraSetting.canRegisterInWaitingList,
   
      //})
    });
  }
  SetDaysDate(Dates: Date[]) {
    Dates.forEach(x => {
      $(".DateInput").val(x.toString())
      this.AddDay();
    })
    $(".DateInput").val("");
    this.EnableBtns()
  }

  GetExtraSettingObj(): CourseExtraSetting {
    let ExtraSetting: CourseExtraSetting = new CourseExtraSettingImplement();
    try {
      ExtraSetting.schoolCertificate = this.CourseForm.controls["schoolCertificate"].value
      ExtraSetting.jobDescription = this.CourseForm.controls["jobDescription"].value
      ExtraSetting.saudiPostalCode = this.CourseForm.controls["saudiPostalCode"].value
      ExtraSetting.buildingNumber = this.CourseForm.controls["buildingNumber"].value
      ExtraSetting.streetNumber = this.CourseForm.controls["streetNumber"].value
      ExtraSetting.postalCode = this.CourseForm.controls["postalCode"].value
      ExtraSetting.extraCode = this.CourseForm.controls["extraCode"].value
      ExtraSetting.fillExcelForProfessionalCourse = this.CourseForm.controls["fillExcelForProfessionalCourse"].value
      ExtraSetting.fillWordForProfessionalCourse = this.CourseForm.controls["fillWordForProfessionalCourse"].value
      ExtraSetting.fillEnergyForm = this.CourseForm.controls["fillEnergyForm"].value
      ExtraSetting.approvalLetter = this.CourseForm.controls["approvalLetter"].value
      ExtraSetting.canLeave = this.CourseForm.controls["canLeave"].value
      ExtraSetting.canChangeDate = this.CourseForm.controls["canChangeDate"].value
      ExtraSetting.canLeaveAndMoneyBack = this.CourseForm.controls["canLeaveAndMoneyBack"].value
      ExtraSetting.canRedoTest = this.CourseForm.controls["canRedoTest"].value
      ExtraSetting.canChangeTestDate = this.CourseForm.controls["canChangeTestDate"].value
      ExtraSetting.canRegisterInWaitingList = this.CourseForm.controls["canRegisterInWaitingList"].value
    } catch (err) {

    }

    return ExtraSetting;
  }
  EnableBtns() {
    if (this.ThisUrl== "ById") {
      this.CourseForm.disable();
      this.btnsave = false;
      this.btnedit = false;
    } else if (this.ThisUrl == "Edit") {
      this.btnsave = false;
      this.btnedit = true;
    } else {
      this.btnsave = true;
      this.btnedit = false;
    }
  }
  CheckDatesBetween(From,To,Compare) {
    var dateFrom = From;
    var dateTo = To;
    Compare = Compare.toLocaleDateString('fr-CA')
    var d1 = dateFrom.split("-");
    var d2 = dateTo.split("-");
    var c = Compare.split("-");
    var D1Y = d1[2];
    var from = new Date(d1[0], parseInt(d1[1]) - 1, d1[2]);  // -1 because months are from 0 to 11
    var to = new Date(d2[0], parseInt(d2[1]) - 1, d2[2]);
    var check = new Date(c[0], parseInt(c[1]) - 1, c[2]);
    return (check >= from && check <= to)
  }
  onExit() {
    this.router.navigate(["/rvrgstr/ViewCourses/"]);
  }
  ValidateSeatsAndMarks() {
    let highestScore = this.CourseForm.controls["highestScore"].value
    let miminumAttendance = this.CourseForm.controls["miminumAttendance"].value
    let minimumSuccessScore = this.CourseForm.controls["minimumSuccessScore"].value
    if (miminumAttendance > this.CourseDays) {
      this.CourseForm.controls["miminumAttendance"].setErrors({ 'MinAttendance': true });
    }
    if (highestScore < minimumSuccessScore) {
      this.CourseForm.controls["minimumSuccessScore"].setErrors({ 'MinScore': true });
    }
  }
  ChangeCourseName(Elm) {
    this.CourseForm.controls["courseName"].setValue(Elm);
  }
  CourseTypeIdChanged(Elm) {
    if (Elm == 1) {
      this.CourseForm.controls["courseName"].setValue("");
      this.CourseForm.controls["courseName"].setErrors({ 'incorrect': true });
    }
  }
}
