import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ButtonModule } from 'primeng/button';
import { TestComponent } from "./test/test.component";
import { Error404Component } from './error404/error404.component';
import { RouterModule } from "@angular/router";
import { MainViewComponent } from './main-view/main-view.component';
import { Table, TableModule } from "primeng/table";
import { DialogModule } from "primeng/dialog";
import { ToastModule } from "primeng/toast";
import { TranslateModule } from "@ngx-translate/core";
import { ConfirmDialogModule } from "primeng/confirmdialog";
import { TraineeListParentComponent } from "./TraineeListParent/traineeListParent.component";
import { HeaderSharedComponent } from "./headerShared/headerShared.component";
import { SideMenuSharedComponent } from "./SideMenuShared/SideMenuShared.component";
import { MultiSelectModule } from "primeng/multiselect";
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { ViewCoursesComponent } from "../RevisionRegister/ViewCourses/ViewCourses.component";
import { MangeCourseComponent } from "./CourseMangment/MangeCourse/MangeCourse.component";
import { ViewcoursesSharedComponent } from "./CourseMangment/viewcoursesShared/viewcoursesShared.component";
import {DropdownModule} from 'primeng/dropdown';


@NgModule({
  declarations: [TestComponent,
    Error404Component,
    MainViewComponent,
    TraineeListParentComponent,
    HeaderSharedComponent,
    SideMenuSharedComponent,
    MangeCourseComponent,
    ViewcoursesSharedComponent

  ],
  imports: [
    TableModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    DialogModule,
    ProgressSpinnerModule,
    ConfirmDialogModule,
    RouterModule,
    ToastModule,
    TranslateModule,
    MultiSelectModule,
    DropdownModule
  ],

  exports: [
    TableModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    DialogModule,
    ConfirmDialogModule,
    RouterModule,
    ToastModule,
    TranslateModule,
    MultiSelectModule,

    TraineeListParentComponent,
    HeaderSharedComponent,
    SideMenuSharedComponent,
    MangeCourseComponent,
    ViewcoursesSharedComponent

    ],
})
export class SharedModule { }
