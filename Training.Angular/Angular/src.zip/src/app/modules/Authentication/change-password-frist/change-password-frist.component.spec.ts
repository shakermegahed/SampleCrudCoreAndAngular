import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangePasswordFristComponent } from './change-password-frist.component';

describe('ChangePasswordFristComponent', () => {
  let component: ChangePasswordFristComponent;
  let fixture: ComponentFixture<ChangePasswordFristComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangePasswordFristComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePasswordFristComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
