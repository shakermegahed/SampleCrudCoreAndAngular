import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators ,FormBuilder} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ChangpasswordService } from 'src/app/Services/Authentication/changpassword.service';
import { CustomValidators } from 'src/app/Services/Authentication/custom-validators';


@Component({
  selector: 'app-change-password-frist',
  templateUrl: './change-password-frist.component.html',
  styleUrls: ['./change-password-frist.component.css'],
  providers: [MessageService, ConfirmationService]
})
export class ChangePasswordFristComponent implements OnInit {
  ChangePasswordFristForm:FormGroup;
  constructor(private myservice:ChangpasswordService,private route:ActivatedRoute, private fb: FormBuilder,
    private Router: Router,private formBuilder: FormBuilder,  private messageService: MessageService,) {
      this.ChangePasswordFristForm = this.createpasswordForm();

      
     }

    
     confirmPassword;
     show = false;
     password:string;
  submitted= false;
  
  Token = this.route.snapshot.paramMap.get('Token');
  ngOnInit(): void {


this.createpasswordForm();





  }

     // convenience getter for easy access to form fields

  changpassword(){
console.log(this.Token)
this.submitted = true;
if (this.ChangePasswordFristForm.invalid) {
  return;
}else{

  this.password= this.ChangePasswordFristForm.get('password').value;
  this.submitted = true;


    this.myservice.ChangePasswordFirstTime(this.Token,this.password)
    .subscribe(
      (result) => {

        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: "Success",
            detail: result.message,
            
          });
                
      this.Router.navigateByUrl('/Authentication/login');  
          }
        else {
          this.messageService.add({
            severity: "error",
            summary: "Error",
            detail: result.message,
          });
        }

     
  
      },
      (err) => {
        //...
      }
    );



  
  }
}


  createpasswordForm(): FormGroup {
    return this.fb.group(
      {
     
        password: [
          null,
          Validators.compose([
            Validators.required,
            // check whether the entered password has a number
            CustomValidators.patternValidator(/\d/, {
              hasNumber: true
            }),
            // check whether the entered password has upper case letter
            CustomValidators.patternValidator(/[A-Z]/, {
              hasCapitalCase: true
            }),
            // check whether the entered password has a lower case letter
            CustomValidators.patternValidator(/[a-z]/, {
              hasSmallCase: true
            }),
            // check whether the entered password has a special character
            CustomValidators.patternValidator(
              /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
              {
                hasSpecialCharacters: true
              }
            ),
            Validators.minLength(8)
          ])
        ],
        confirmPassword: [null, Validators.compose([Validators.required])]
      },
      {
        // check whether our password and confirm password match
        validator: CustomValidators.passwordMatchValidator
      }
    );
  }


  onClickpassword() {
  //   if (this.password === 'password') {
  //     this.password = 'text';
  //     this.show = true;
  //   } else {
  //     this.password = 'password';
  //     this.show = false;
  //   }
  // }
  }
}
