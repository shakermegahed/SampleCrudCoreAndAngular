import { SharedModule } from './../shared/shared.module';
import { ButtonModule } from 'primeng/button';
import { AuthRoutingModule } from './auth-router.routing';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { TableModule } from 'primeng/table';
import { LogInComponent } from './LogIn/LogIn.component';
import { AuthenticationComponent } from './Authentication.component';
import { RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ChangePasswordFristComponent } from './change-password-frist/change-password-frist.component';
import { ProgressSpinnerModule } from 'primeng/progressspinner';


@NgModule({
  imports: [
  
    AuthRoutingModule,
    TranslateModule, //  To Allow Translation in This Module
    CommonModule,
    TableModule,
    RouterModule,
    ProgressSpinnerModule,
 
    FormsModule, ReactiveFormsModule
  ],
  declarations: [AuthenticationComponent,LogInComponent, SignupComponent, ChangePasswordFristComponent]
})

export class AuthModule { }
