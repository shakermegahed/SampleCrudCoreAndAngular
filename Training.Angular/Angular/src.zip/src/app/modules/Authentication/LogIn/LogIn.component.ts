import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/internal/Subscription';
import { AuthenticateService } from 'src/app/Services/Authentication/authenticate.service';

@Component({
  selector: 'app-LogIn',
  templateUrl: './LogIn.component.html',
  styleUrls: ['./LogIn.component.scss']
})
export class LogInComponent implements OnInit {

  constructor(private Router: Router, private authenticateService: AuthenticateService) { }
  LoginDataForm: FormGroup;
  loadingSpinner: boolean = false;
  errorMessage: any;
  subscription: Subscription;
  ngOnInit() {
    this.LoginDataForm = new FormGroup({
      userName: new FormControl('',Validators.required),
      password: new FormControl('', Validators.required)
    })
  }

  // LogIn() {
  //   this.authenticateService.AuthenticateUser(this.LoginDataForm.value).subscribe(result => {
  //     console.log("login",result.Message);
  //     console.log("result of authenticate :- ", result);
  //     let role = result.userRoles[0];
  //     if (role.toLowerCase() == "admin")
  //     {
  //       this.router.navigate(["/", "admin"]);
  //     }
  //     else if (role.toLowerCase() == "user")
  //     {
  //       this.router.navigate(["/", "admin"]);
  //     }
  //     else if (role.toLowerCase() == "revision supervisor")
  //     {
  //       this.router.navigate(["/", "rvrgstr"]);
  //     }
  //     else if (role.toLowerCase() == "revision register")
  //     {
  //       this.router.navigate(["/", "rvrgstr"]);
  //     }

  //   })
    

  // }


  LogIn() {
    this.loadingSpinner = true;

   this.subscription=this.authenticateService.AuthenticateUser(this.LoginDataForm.value)
      .subscribe(
        res => {

          if (res.succeeded ==true){
          this.loadingSpinner = false;
    
          localStorage.setItem('token', res.token);
          localStorage.setItem('name', res.name);
           localStorage.setItem('userRoles', res.userRoles[0]);
           let role = res.userRoles[0];
          if (role.toLowerCase() == "admin")
              {
                this.Router.navigate(["/", "admin"]);
              }
              else if (role.toLowerCase() == "user")
              {
                this.Router.navigate(["/", "admin"]);
              }
              else if (role.toLowerCase() == "revision supervisor")
              {
                this.Router.navigate(["/", "rvrgstr"]);
              }
              else if (role.toLowerCase() == "revision register")
              {
                this.Router.navigate(["/", "rvrgstr"]);
              }
            }else{
              this.errorMessage=res.message;
            
              console.log( "dsadsadsadsadsa")
              this.Router.navigate(['Authentication']);
              // errorHandling(err, this.Router.navigate(['']), this.showAlert = true);
              this.loadingSpinner = false;

            }


         
        })
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event

    this.subscription.unsubscribe();


  }

}
