import { AuthenticateService } from './../../Services/Authentication/authenticate.service';
import { Injectable } from '@angular/core';
import { CanActivate, Router } from "@angular/router";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private AuthService: AuthenticateService,
    private Router: Router) { }

  canActivate(): boolean {
    console.log("hi    is role :- ");
    // if (this.AuthService.loggedIn()) {
    //   return true
    // } else {
    //   this.Router.navigate(['/login'])
    //   return false
    // }
    return true;
  }
}
