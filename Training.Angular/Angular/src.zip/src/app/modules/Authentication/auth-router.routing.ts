import { NgModule, Component } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { AuthenticationComponent } from './Authentication.component';
import { ChangePasswordFristComponent } from './change-password-frist/change-password-frist.component';

import { LogInComponent } from './LogIn/LogIn.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path: "",
    component: LogInComponent
  },
  {
    path: "login",
    component: LogInComponent
  },
  {
    path: "signup",
    component: SignupComponent
  },

  {
    path: "createpassword/:Token",
    component: ChangePasswordFristComponent
  },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})


export class AuthRoutingModule { }
