import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from 'src/app/Services/Shared/shared.service';

@Component({
  selector: 'app-Authentication',
  templateUrl: './Authentication.component.html',
  styleUrls: ['./Authentication.component.scss']
})
export class AuthenticationComponent implements OnInit {

  constructor(public translate: TranslateService, public shared: SharedService) { }
  CurrentLang :any
  changeCurrentLang(lang: string) {
    this.shared.changeCurrentLang(lang)
    this.CurrentLang = lang
  }
  ngOnInit() {
  }

}
