import { DeleteTrainee } from './../../../../models/Admin/DeleteTrainee';
import { HttpClient } from "@angular/common/http";
import { FormArray, FormControl, FormGroup, Validators } from "@angular/forms";
import { Title } from "@angular/platform-browser";
import { TranslateService } from "@ngx-translate/core";
import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { LazyLoadEvent, MessageService } from "primeng/api";

import { Subscription } from "rxjs";
import { ReviewUsersService } from "src/app/Services/Admin/Users/review-users.service";
import { AccountsService } from "src/app/Services/Accounts/accounts.service";
import { ReviewCoursesService } from "src/app/Services/Courses/review-courses.service";
import { ReviewUsersDTO } from "src/app/models/Admin/ReviewUsersDTO";
import { ReviewUsersFilter } from "../../../../models/Admin/ReviewUsersFilter";
import { LookupDto } from "src/app/models/Common/WorkPlaceDTO";


@Component({
  selector: 'app-review-users',
  templateUrl: './review-users.component.html',
  styleUrls: ['./review-users.component.scss'],
  providers: [MessageService]
})
export class ReviewUsersComponent implements OnInit {
  @ViewChild("closeModal") closeModal;
  @ViewChild("SaveModal") SaveModal;
  @ViewChild("EditModal") EditModal;
  userId: string;
  btnsave = false;
  btnedit = false;
  displayReason = false;
  displayModal = false;
  displayModalActiveInActive = false;
  selectedIdForDelete: string;
  selectedIdForActivate: string;


  tranieename: string;

  elements: ReviewUsersDTO[];
  totalRecords: number = 0;
  formSubmitted: boolean = false;
  loading: boolean = true;
  Roles: LookupDto[] = [];
  CoursesTypes: LookupDto[] = [];
  CoursesTypesSelected: any = [];

  constructor(
    private translate: TranslateService,
    private UserService: ReviewUsersService,
    private RegService: AccountsService,
    private CourseService: ReviewCoursesService,
    private messageService: MessageService) {

  }

  ngOnInit(): void {
    this.UserForm = new FormGroup({
      //fullName: new FormControl("", Validators.required),

      firstName: new FormControl("", Validators.required),
      secondName: new FormControl("", Validators.required),
      thirdName: new FormControl("", Validators.required),
      lastName: new FormControl("", Validators.required),
      gender: new FormControl(1),
      ssNumber: new FormControl("", [Validators.required, Validators.pattern("^(1|2)[0-9]{9}$")]),
      email: new FormControl("", [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      userName: new FormControl("", Validators.required),
      status: new FormControl(true),
      department: new FormControl("", Validators.required),
      workPlace: new FormControl(""),
      jobDescription: new FormControl("", Validators.required),
      birthDate: new FormControl("", Validators.required),
      role: new FormControl("", Validators.required),
      phoneNumber: new FormControl("", [Validators.required, Validators.pattern("^(05)([0-9]{8})$")]),
      userId: new FormControl(""),
      courseTypesId: new FormControl("")
    });
    this.UsersFormForSearch = new FormGroup({
      fullName: new FormControl("", Validators.required),
      email: new FormControl("", Validators.required),
      ssNumber: new FormControl("", Validators.required),
      pageIndex: new FormControl("", Validators.required),
      pageSize: new FormControl("", Validators.required)

    });

    this.RegService.GetRoles().subscribe(result => {
      this.Roles = result.list;
    })

    this.CourseService.GetCourseTypes().subscribe(result => {
      this.CoursesTypes = result.list;
    })
  }

  UserFormForActivate: FormGroup = new FormGroup({
    status: new FormControl(true),
    reason: new FormControl("", Validators.required),
    userId: new FormControl(""),
  });
  UsersFormForSearch: FormGroup = new FormGroup({});
  UserForm: FormGroup = new FormGroup({});

  firstName: string;
  secondName: string;
  thirdName: string;
  lastName: string;

  get FacultyErrors() {
    return this.UserForm.controls;
  }



  subscriptionb: Subscription;

  ActivateDeatcivateTrainee() {
    this.UserFormForActivate.value.userId = this.selectedIdForActivate
    this.subscriptionb = this.UserService
      .ActiveUser(this.UserFormForActivate.value)
      .subscribe((result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message
          });
          this.toggleModal(false);
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message
          });
        }
        this.displayModal = false;
        this.GetUsersData();
      });
  }

  GetUsersData() {
    // this.filter.pageIndex = 10;
    // this.filter.pagelength = 0;

    this.UsersFormForSearch.patchValue({
      pageIndex: 0,
      pageSize: 10
    })

    this.subscriptionb = this.UserService.GetUsers(this.UsersFormForSearch.value).subscribe((resp) => {
      this.elements = resp.list;
      //this.totalRecords = resp.length;
      this.totalRecords = resp.resultPaging.recordsFiltered;
      console.log(resp);
    });
  }

  SearchUsers() {
    this.GetUsersData();
  }


  toggleModal(value) {
    this.displayModalActiveInActive = value;
  }

  loadUsers(event: LazyLoadEvent) {
    this.loading = true;
    const filter: ReviewUsersFilter = new ReviewUsersFilter();
    filter.pageIndex = event.first / event.rows;
    filter.pageSize = event.rows;
    this.UserService.GetUsers(filter).subscribe(result => {
      this.elements = result.list;
      this.loading = false;
      this.totalRecords = result.resultPaging.recordsFiltered;
    })
  }

  onSubmit() {

    if (this.UserForm.valid) {
      this.SaveModal.nativeElement.disabled = true;
      this.UserForm.value.HostName = this.GetUrl();
      this.UserForm.value.status = true;
      this.UserForm.value.gender = 1;

      this.subscriptionb = this.RegService
        .RegisterationByAdmin(this.UserForm.value)
        .subscribe(
          (result) => {
            if (result.success) {
              this.messageService.add({
                severity: "success",
                summary: this.translate.instant('Success'),
                detail: result.message,
              });
              this.closeModal.nativeElement.click();
              this.SaveModal.nativeElement.disabled = false;

              this.GetUsersData();
              this.onReset();
            }
            else {
              this.messageService.add({
                severity: "error",
                summary: this.translate.instant('Error'),
                detail: result.message
              });
              this.SaveModal.nativeElement.disabled = false;

            }

            //console.log("Add Traniee ", res);
          },
          (err) => {
            //...
          }
        );
    } else {
      this.UserForm.markAllAsTouched();
    }

  }
  onSubmitEdit() {
    if (this.UserForm.valid) {
      this.EditModal.nativeElement.disabled = true;
      this.subscriptionb = this.UserService
        .UpdateUser(this.UserForm.value)
        .subscribe(
          (result) => {
            if (result.success) {
              this.messageService.add({
                severity: "success",
                summary: this.translate.instant('Success'),
                detail: result.message,
              });
              this.closeModal.nativeElement.click();
              this.EditModal.nativeElement.disabled = false;

              this.GetUsersData();
              this.onReset();
            }
            else {
              this.messageService.add({
                severity: "error",
                summary: this.translate.instant('Error'),
                detail: result.message,
              });
              this.EditModal.nativeElement.disabled = false;
            }

            //console.log("Add Traniee ", res);
          },
          (err) => {
            //...
          }
        );
    } else {
      this.UserForm.markAllAsTouched();
    }
  }

  onReset() {
    this.UserForm.reset();
  }

  askConfirmActivate(model: ReviewUsersDTO) {
    console.log("hi ");
    this.displayModalActiveInActive = true;
    this.selectedIdForActivate = model.userId;
    this.UserService.GetUserStatus(this.selectedIdForActivate).subscribe(result => {
      this.UserFormForActivate.patchValue({
        // fullName: result.firstName + result.secondName + result.thirdName + result.lastName,
        status: result.status
      })
      this.firstName = model.firstName;
      this.secondName = model.secondName;
      this.thirdName = model.thirdName;
      this.lastName = model.lastName;
      this.displayReason = !result.status;

    })
  }

  viewmodeledit(userId) {
    this.UserForm.enable();
    this.UserForm.addControl("userId", new FormControl("", Validators.required));
    this.btnsave = false;
    this.btnedit = true;
    //this.UserForm.controls['email'].disable();
    this.UserForm.controls['status'].disable();
    try {
      this.EditModal.nativeElement.disabled = false;
    } catch (err) {

    }

    this.subscriptionb = this.UserService
      .GetUsersById(userId)
      .subscribe((resp) => {
        console.log(resp);
        this.UserForm.patchValue({

          firstName: resp.firstName,
          secondName: resp.secondName,
          thirdName: resp.thirdName,
          lastName: resp.lastName,

          //fullName: resp.fullName,
          gender: resp.gender,
          ssNumber: resp.ssNumber,
          email: resp.email,
          userName: resp.userName,
          status: resp.status,
          department: resp.department,
          workPlace: resp.workPlace,
          jobDescription: resp.jobDescription,
          birthDate: resp.birthDate,
          role: resp.roleId,
          phoneNumber: resp.phoneNumber,
          userId: resp.userId,
        });
        this.CoursesTypesSelected = resp.courseTypesId;
      });
  }


  DeleteTrainee() {
    let DeleteGovernment: DeleteTrainee = {
      IsDeleted: true,
      TranieeId: this.selectedIdForDelete,
    };

    this.UserService
      .DeleteUnDeleteTraniee(DeleteGovernment)
      .subscribe((result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }
        this.displayModal = false;
        this.GetUsersData();
      });
  }

  askConfirmDelete(model: ReviewUsersDTO) {


    this.displayModal = true;

    this.selectedIdForDelete = model.userId;
    this.tranieename = model.firstName + ' ' + model.lastName + ' ' + model.thirdName + ' ' + model.lastName;
    console.log(
      "askConfirmDelete",
      this.selectedIdForDelete,
      this.tranieename);
  }

  viewmodel(userId) {

    this.viewmodeledit(userId);
    this.UserForm.disable();
    this.btnedit = false;
    this.btnsave = false;
  }
  OpenModelAdd() {
    this.UserForm.enable();
    this.onReset();
    this.UserForm.removeControl("userId");
    this.btnsave = true;
    this.btnedit = false;
  }

  onCheckboxChange(e) {
    console.log("hi from change ", e.target.checked)
    if (e.target.checked) {
      this.displayReason = false;
    }
    else {
      this.displayReason = true;
    }
  }
  GetUrl() {
    var url = window.location.href
    var arr = url.split("/");
    return arr[0] + "//" + arr[2];
  }
  setUserName(val) {
    if (this.btnsave) {
      this.UserForm.controls['userName'].setValue(val);
    }
  }
}
