import { SharedModule } from './../shared/shared.module';
import {ToastModule} from 'primeng/toast';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { AdminRoutingModule } from './admin-router.routing';
import { AdminHomePageComponent } from './AdminHomePage/AdminHomePage.component';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';

import { ReviewTraineesComponent } from './TraineeManagment/review-trainees/review-trainees.component';
import { ReviewUsersComponent } from './UserMangment/review-users/review-users.component';
import { TableModule } from 'primeng/table';
import {ConfirmDialogModule} from 'primeng/confirmdialog';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    //TranslateModule, //  To Allow Translation in This Module
    CommonModule,
    AdminRoutingModule,
     //TableModule,
    //FormsModule ,
    //ReactiveFormsModule,
    //ConfirmDialogModule,
    TranslateModule.forRoot({
      defaultLanguage: 'ar',
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      isolate: true
    }),
    CommonModule, AdminRoutingModule,
     //TableModule,
     ButtonModule,DialogModule,
     ToastModule,
     SharedModule

  ],
  declarations: [
    //UserListParentComponent,
    AdminHomePageComponent,
    ReviewTraineesComponent,
    // ReviewUsersComponent,
    AdminHomePageComponent,
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
})


export class AdminModule { }
