import { MangeCourseComponent } from './../shared/CourseMangment/MangeCourse/MangeCourse.component';
import { ViewcoursesSharedComponent } from './../shared/CourseMangment/viewcoursesShared/viewcoursesShared.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminHomePageComponent } from './AdminHomePage/AdminHomePage.component';
import { ReviewTraineesComponent } from './TraineeManagment/review-trainees/review-trainees.component';
import { ReviewUsersComponent } from './UserMangment/review-users/review-users.component';

const routes: Routes = [
  {
    path: "",
		component: AdminHomePageComponent,
    children: [
      { path: "ReviewTrainees", component: ReviewTraineesComponent },
      { path: "ReviewUsers", component: ReviewUsersComponent },
      { path: "MangeCourses", component: MangeCourseComponent },
      { path: "ViewCourses", component: ViewcoursesSharedComponent }
    ]
  },
];


@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})


export class AdminRoutingModule {}
