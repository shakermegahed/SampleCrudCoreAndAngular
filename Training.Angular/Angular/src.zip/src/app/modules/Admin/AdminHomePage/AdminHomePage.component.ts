import { LookupDto } from './../../../models/Common/WorkPlaceDTO';
import { NavMenu } from './../../../models/Common/NavMenuItem';
import { Component, OnInit } from '@angular/core';
import 'jquery';

@Component({
  selector: 'app-AdminHomePage',
  templateUrl: './AdminHomePage.component.html',
  styleUrls: ['./AdminHomePage.component.css']
})
export class AdminHomePageComponent implements OnInit {


  navItem: NavMenu[] =
  [
    {
      childMenu: [],
      icon     : "mdi mdi-view-dashboard",
      path:"/admin",
      linkTitle:"الصفحة الرئيسية"
    },
    {
    path     : "/admin/ReviewUsers",
    icon     : "mdi mdi-account-circle",
    linkTitle: "ادارة مستخدمى النظام",
    childMenu:[]
  },
  {
    path     : "/admin/ReviewTrainees",
    icon     : "mdi mdi-account-multiple",
    linkTitle: "ادارة المتدربين",
    childMenu: []
  },
  {
    path: "/admin/ViewCourses",
    icon     : "mdi mdi-content-paste",
    linkTitle: "ادارة الدورات التدريبية",
    childMenu: []
  },
  {
    path     : "/",
    icon     : "mdi mdi-account-multiple",
    linkTitle: "تسجيل خروج",
    childMenu:[]
  },
  ];

  constructor()
  {

  }
   ngOnInit() {
     console.log("this is home page for admin ", this.navItem);
  }

}
