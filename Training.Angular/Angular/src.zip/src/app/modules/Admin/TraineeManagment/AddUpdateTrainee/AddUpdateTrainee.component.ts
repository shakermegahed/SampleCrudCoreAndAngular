import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-AddUpdateTrainee',
  templateUrl: './AddUpdateTrainee.component.html',
  styleUrls: ['./AddUpdateTrainee.component.scss']
})
export class AddUpdateTraineeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
