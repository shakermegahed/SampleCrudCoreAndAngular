import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewTraineesComponent } from './review-trainees.component';

describe('ReviewTraineesComponent', () => {
  let component: ReviewTraineesComponent;
  let fixture: ComponentFixture<ReviewTraineesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewTraineesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewTraineesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
