/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ViewTraineeforRvsRgstrComponent } from './ViewTraineeforRvsRgstr.component';

describe('ViewTraineeforRvsRgstrComponent', () => {
  let component: ViewTraineeforRvsRgstrComponent;
  let fixture: ComponentFixture<ViewTraineeforRvsRgstrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewTraineeforRvsRgstrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTraineeforRvsRgstrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
