import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";

import {
  ConfirmationService,
  LazyLoadEvent,
  MessageService,
} from "primeng/api";

import { RevisionRegisterService } from "../../../Services/RevisionRegister/RevisionRegister.service";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { GovernmentaService } from 'src/app/Services/RevisionRegister/Governmental/governmenta.service';
import { TranslateService } from '@ngx-translate/core';
import { GovernmentalFilter } from 'src/app/models/RevisionRegister/Governmental/GovernmentalFilter';
import { DeleteGovernmentDTO } from 'src/app/models/RevisionRegister/Governmental/DeleteGovernmentDTO';
import { GovernmentalDTO } from 'src/app/models/RevisionRegister/Governmental/GovernmentalDTO';
import * as XLSX from "xlsx";
import { element } from "protractor";

@Component({
  selector: "app-governmental-entities",
  templateUrl: "./governmental-entities.component.html",
  styleUrls: ["./governmental-entities.component.css"],
  providers: [MessageService, ConfirmationService],
})
export class GovernmentalEntitiesComponent implements OnInit {
  elements: any;
  errorElements: any;
  government: FormGroup = new FormGroup({});
  ActiveGovernmentForm: FormGroup;
  ImportFileForm:FormGroup;
  UpdateGovName:FormGroup;
  displayModalActiveInActive = false;
  selectedIdForActivate: number;
  titleGovernmental: string;
  Showingpagination: string;
  TOpagination: string;
  Ofpagination: string;
  Entriespagination: string;

  loading: boolean = true;
  totalRecords: number = 0;
  governmentFormForSearch: FormGroup;
  SendmailForm: FormGroup;
  btnsave: boolean = false;
  btnedit: boolean = false;
  formSubmitted: boolean = false;
  selectedIdForDelete: number;

  formSubmittedSemail: boolean = false;
  translation_words: any = [];
  position: string;
  filter: GovernmentalFilter = new GovernmentalFilter();
  displayPosition: boolean;
  displaySendmail:boolean;
  displayexportExcel:boolean;
  displayModalDelete:boolean;
  displayImportExcel:boolean;
  fileToUpload: File = null;
  isLoading=false;
  hasError=false;

  constructor(private httpclient:HttpClient,private myservices:GovernmentaService,public  translate: TranslateService,
    public RevisionRegisterService: RevisionRegisterService, 
    private messageService: MessageService,

    private confirmationService: ConfirmationService
  ) {

    this.Showingpagination = 'General.Showing';
    this.TOpagination = 'General.to';
    this.Ofpagination = 'General.of';
    this.Entriespagination = 'General.entries';
    //  Get Translated Text
    translate.get(["Yes", "No", "DeleteConfirmation"]).subscribe((values) => {
      console.log("Loaded values", values);
      this.translation_words = {
        ConfirmationText: values.DeleteConfirmation,
        ConfirmationYes: values.No,
        ConfirmationNo: values.Yes,
      };
    });
  }

  ngOnInit(): void {
    this.ImportFileForm=new FormGroup({importExlFile:new FormControl("")});
    this.UpdateGovName=new FormGroup({governmentalName:new FormControl(""),governmentalId: new FormControl("")});
    this.government = new FormGroup({
      governmentalName: new FormControl("", Validators.required),
      email: new FormControl("", [
        Validators.required,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
      ]),
      address: new FormControl("", Validators.required),
      responsible:new FormControl("",Validators.required),
      phone: new FormControl("", [
        Validators.required,
        Validators.pattern("^[0-9]{10}$"),
      ]),
      mobile: new FormControl("", [
        Validators.required,
        Validators.pattern("^[0-9]{10}$"),
      ]),
      status: new FormControl(""),
      allowTrainee: new FormControl(""),
      governmentalId: new FormControl(""),
    });

    this.SendmailForm = new FormGroup({
      title: new FormControl("", Validators.required),
      message: new FormControl("", Validators.required),
    });
    this.ActiveGovernmentForm = new FormGroup({
      governmentalName: new FormControl(""),
      status: new FormControl("", Validators.required),
      governmentalId: new FormControl(""),
    });

    this.governmentFormForSearch = new FormGroup({
      orderBy: new FormControl(""),
      name: new FormControl("", Validators.required),

      pageIndex: new FormControl("", Validators.required),
      pageSize: new FormControl("", Validators.required),
    });
    // this.getAllGovermentalEntities();
  }

  OpenModelAdd() {
    console.log("OpenModelAdd");
    this.btnsave = true;
    this.btnedit = false;
  }

  onSubmitedit() {
    this.formSubmitted = true;

    if (this.government.invalid) {
      this.formSubmitted = true;
      return;
    }
    this.formSubmitted = true;

    this.myservices.UpdateGovernment(this.government.value).subscribe(
      (result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }

        this.displayPosition = false;

        this.GetgovernmentData();
        this.onReset();
      },
      (err) => {
        //...
      }
    );
  }
  onSubmitNameEdit() {
  

    this.myservices.UpdateGovernmentName(this.UpdateGovName.value).subscribe(
      (result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }

        this.displayPosition = false;

        this.GetgovernmentData();
        this.onReset();
      },
      (err) => {
        //...
      }
    );
  }
  SearchGovernment() {
    this.GetgovernmentData();
  }

  onSubmit() {
    this.formSubmitted = true;

    if (this.government.invalid) {
      this.formSubmitted = true;
      return;
    }
    this.formSubmitted = true;

    this.myservices.Addgovernment(this.government.value).subscribe(
      (result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }
        this.GetgovernmentData();
        this.displayPosition = false;

        this.onReset();
        //console.log("Add Traniee ", res);
      },
      (err) => {
        //...
      }
    );
  }

  // getAllGovermentalEntities() {
  //   this.httpclient.get("https://jsonplaceholder.typicode.com/todos").subscribe(res => {
  //     this.elements = res;
  //     console.log(res);
  //   })
  // }

  GetviewInfo(id) {
    this.titleGovernmental = 'Governmental.Governmentreview';
    this.displayPosition = true;
    this.government.disable();

    this.btnsave = false;
    this.btnedit = false;

    this.myservices.GetGovernmentById(id).subscribe((resp) => {
      this.government.patchValue({
        governmentalName: resp.governmentalName,
        email: resp.email,
        address: resp.address,
        responsible:resp.responsible,
        phone: resp.phone,
        mobile: resp.mobile,
        status: resp.status,
        allowTrainee: resp.allowTrainee,
      });
      console.log(resp);
    });
    console.log("GetInfo", id);
  }

  SendMail(id) {
    console.log("SendMail", id);
  }

  askConfirmDelete(model: GovernmentalDTO) {
    console.log(
      "askConfirmDelete",
      (this.selectedIdForDelete = model.governmentalId)
    );

    this.displayModalDelete = true;

    this.selectedIdForDelete = model.governmentalId;
  }




  DeleteGovernment() {
    let DeleteGovernment: DeleteGovernmentDTO = {
      IsDeleted: true,
      GovernmentId: this.selectedIdForDelete,
    };

    this.myservices
      .DeleteGovernment(DeleteGovernment)
      .subscribe((result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }
        this.GetgovernmentData();
        this.displayModalDelete = false;
      });
  }


  EditRow(id) {
    this.titleGovernmental = 'Governmental.Modifygovernment';

    this.government.addControl(
      "governmentalId",
      new FormControl("", Validators.required)
    );

    this.government.enable();
    this.displayPosition = true;
    this.btnsave = false;
    this.btnedit = true;

    this.myservices.GetGovernmentById(id).subscribe((resp) => {
      this.government.patchValue({
        governmentalName: resp.governmentalName,
        email: resp.email,
        address: resp.address,
        responsible:resp.responsible,
        phone: resp.phone,
        mobile: resp.mobile,
        status: resp.status,
        allowTrainee: resp.allowTrainee,
        governmentalId: resp.governmentalId,
      });

      console.log(resp);
    });
    console.log("GetInfo", id);
  }

  onReset() {
    this.formSubmitted = false;
    this.government.enable();

    this.government.reset();
  }

  onSubmitSendmail() {
    if (this.SendmailForm.invalid) {
      this.formSubmittedSemail = true;

      this.formSubmitted = true;
      return;
    }
  }

  loadCustomers(event: LazyLoadEvent) {
    this.loading = true;
    const filter: GovernmentalFilter = new GovernmentalFilter();
    filter.pageIndex = event.first / event.rows;
    filter.pageSize = event.rows;
    this.myservices.GetGovernments(filter).subscribe((result) => {
      this.elements = result.list;
      this.loading = false;
      this.totalRecords = result.resultPaging.recordsFiltered;
      console.log("tes", result.list);
    });
  }

  GetgovernmentData() {

    this.governmentFormForSearch.patchValue({
      pageIndex: 0,
      pageSize: 10,
    });
    // this.filter.pageIndex = 10;
    // this.filter.pagelength = 0;
    this.myservices
      .GetGovernments(this.governmentFormForSearch.value)
      .subscribe((resp) => {
        this.elements = resp.list;
        //this.totalRecords = resp.length;
        this.totalRecords = resp.resultPaging.recordsFiltered;
        console.log("GetGovernments", resp);
      });
  }

  askConfirmActivate(model: GovernmentalDTO) {
    console.log("hi ");
    this.displayModalActiveInActive = true;
    this.selectedIdForActivate = model.governmentalId;
    this.myservices
      .GetGovernmentById(this.selectedIdForActivate)
      .subscribe((result) => {
        this.ActiveGovernmentForm.patchValue({
          governmentalName: result.governmentalName,
          status: result.status,
        });
      });
  }

  ActiveGovernment() {
    this.ActiveGovernmentForm.patchValue({
      governmentalId: this.selectedIdForActivate,
    });
    this.myservices
      .ActiveGovernment(this.ActiveGovernmentForm.value)
      .subscribe((result) => {
        if (result.success) {
          this.messageService.add({
            severity: "success",
            summary: this.translate.instant('Success'),
            detail: result.message,
          });
        } else {
          this.messageService.add({
            severity: "error",
            summary: this.translate.instant('Error'),
            detail: result.message,
          });
        }
        this.displayModalActiveInActive = false;

        this.GetgovernmentData();
      });
  }

  onCheckboxChange(e) {
    console.log("hi from change ", e.target.checked);
    if (e.target.checked) {
    } else {
    }
  }

  showPositionSendmail(position: string) {
    this.position = position;
    this.displaySendmail = true;

    this.displayImportExcel = false;
    this.displayexportExcel = false;

    this.displayPosition = false;
  }

  showPositionexportExcel(position: string) {
    this.position = position;
    this.displayexportExcel = true;

    this.displayImportExcel = false;

    this.displaySendmail = false;
    this.displayPosition = false;
  }

  showPositionImportExcel(position: string) {
    this.position = position;
    this.displayImportExcel = true;
    this.displayexportExcel = false;
    this.displaySendmail = false;
    this.displayPosition = false;
  }

  showPositionDialog(position: string) {
    this.titleGovernmental = 'Governmental.Addgovernment';

    this.government.removeControl("governmentalId");

    this.btnsave = true;
    this.btnedit = false;
    this.position = position;
    this.displayPosition = true;
    this.displayImportExcel = false;
    this.displayexportExcel = false;
    this.displaySendmail = false;
    this.onReset();
  }
  toggleModal(value) {
    this.displayModalDelete = value;
    this.displayModalActiveInActive = value;
  }
  export(): void {

    /* table id is passed over here */

    let element = document.getElementById("excel-table");
    element.tabIndex = 2;
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    ws['!cols'][0] = { hidden: true };
    ws['!cols'][10] = { hidden: true };
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Data");
    /* save to file */
    XLSX.writeFile(wb, "Governments.xlsx");
  }

  handleFileInput(event) {
    this.fileToUpload = <File>event.target.files[0];
  }
  
  importGovernemntsFile(){
    this.isLoading=true;
    const formData: FormData = new FormData();
    formData.append('file', this.fileToUpload, this.fileToUpload.name);
  
  
  
    this.myservices.Importgovernment(formData)

    .subscribe(
      (result) => {
        this.isLoading=false;
        this.displayImportExcel=false
       if (result.list.length>0) {
         let errorCods:string="";
        for (let i = 0; i < result.list.length; i++) {
          if(i==0){
            errorCods= result.list[i].code ;
          }
          else{
            errorCods=errorCods +", "+ result.list[i].code ;
          }
         
        }
        this.hasError=true;
        this.errorElements=result.list;
         this.messageService.add({
          severity: "error",
           summary: errorCods,
           detail: result.message,
         });
         result.list.forEach(c=> console.log(c.code))
       } else {
        this.hasError=false;
         this.messageService.add({
          
           severity: "success",
           summary: "Success",
           detail: result.message,
         });
       }

        this.displayPosition = false;
        this.ImportFileForm.reset();
        this.GetgovernmentData();

     },
     (err) => {
       //...
     }
   );
  }

}
