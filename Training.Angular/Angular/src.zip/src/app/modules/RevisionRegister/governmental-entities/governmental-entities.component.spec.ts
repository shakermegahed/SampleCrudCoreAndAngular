import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GovernmentalEntitiesComponent } from './governmental-entities.component';

describe('GovernmentalEntitiesComponent', () => {
  let component: GovernmentalEntitiesComponent;
  let fixture: ComponentFixture<GovernmentalEntitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GovernmentalEntitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GovernmentalEntitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
