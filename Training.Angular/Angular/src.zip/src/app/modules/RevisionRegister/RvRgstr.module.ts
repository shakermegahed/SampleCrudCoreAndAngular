import { ViewCoursesComponent } from './ViewCourses/ViewCourses.component';
import { RevisionRegisterHomePageComponent } from './RevisionRegisterHomePage/RevisionRegisterHomePage.component';
import { SharedModule } from './../shared/shared.module';
import { MessageModule } from 'primeng/message';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { RvRgstrRoutingModule } from './RvRgstr-router.routing';
import { GovernmentalEntitiesComponent } from './governmental-entities/governmental-entities.component';
import { HttpClient } from '@angular/common/http';
import { EditorModule } from 'primeng/editor';
import { CalendarModule } from "primeng/calendar";
import { ViewTraineeforRvsRgstrComponent } from './ManageTrainee/ViewTraineeforRvsRgstr/ViewTraineeforRvsRgstr.component';
import { ReviewUsersComponent } from '../Admin/UserMangment/review-users/review-users.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
@NgModule({
  imports: [
    RvRgstrRoutingModule,
    SharedModule,
    MessageModule,
    EditorModule,
    CalendarModule,
    TranslateModule.forRoot({
      defaultLanguage: 'ar',
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      isolate: true
    }),
  ],
  declarations: [
    ReviewUsersComponent,
    RevisionRegisterHomePageComponent,
    GovernmentalEntitiesComponent,
    GovernmentalEntitiesComponent,
    ViewTraineeforRvsRgstrComponent,
    ViewCoursesComponent

  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],

})

export class RvRgstrModule { }
