import { NavMenu } from 'src/app/models/Common/NavMenuItem';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-RevisionRegisterHomePage',
  templateUrl: './RevisionRegisterHomePage.component.html',
  styleUrls: ['./RevisionRegisterHomePage.component.css']
})
export class RevisionRegisterHomePageComponent implements OnInit {

  navItem: NavMenu[] =
  [
    {
      childMenu:[],
      path     : "/rvrgstr",
      icon     : "mdi mdi-chart-pie",
      linkTitle: "الرئيسية",
    },
    {
      childMenu:[],
      path     : "/rvrgstr/GovernmentalEntities",

      icon     : "mdi mdi-view-dashboard",
      linkTitle: "ادارة الجهات الحكومية",
    },

    {
      childMenu:[],
      path     : "/rvrgstr/Trainee",
      icon     : "mdi mdi-account-multiple",
      linkTitle: "ادارة المتدربين",
    },
    {
      childMenu: [],
      path: "/rvrgstr/ViewCourses",
      icon     : "mdi mdi-content-paste",
      linkTitle: "ادارة الدورات التدريبية"
    },
    //test
    {
      childMenu:[],
      path     : "/",
      icon     : "mdi mdi-account-multiple",
      linkTitle: "تسجيل خروج"
    },
  ];
  constructor() { }

  ngOnInit() {
  }

}
