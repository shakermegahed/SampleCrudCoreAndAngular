import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ViewCourses',
  templateUrl: './ViewCourses.component.html',
  styleUrls: ['./ViewCourses.component.scss']
})
export class ViewCoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
