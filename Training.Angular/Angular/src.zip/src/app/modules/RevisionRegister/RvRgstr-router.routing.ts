import { ViewCoursesComponent } from './ViewCourses/ViewCourses.component';
import { NgModule, Component } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { ReviewUsersComponent } from '../Admin/UserMangment/review-users/review-users.component';
import { GovernmentalEntitiesComponent } from './governmental-entities/governmental-entities.component';

import { ViewTraineeforRvsRgstrComponent } from './ManageTrainee/ViewTraineeforRvsRgstr/ViewTraineeforRvsRgstr.component';
import { RevisionRegisterHomePageComponent } from './RevisionRegisterHomePage/RevisionRegisterHomePage.component';
// import { AddCourseComponent } from '../shared/CourseMangment/AddCourse/AddCourse.component';
// import { ViewcoursesComponent } from '../shared/CourseMangment/viewcourses/viewcourses.component';
import { MangeCourseComponent } from '../shared/CourseMangment/MangeCourse/MangeCourse.component';

const routes: Routes = [
  {
    path: "", component: RevisionRegisterHomePageComponent,
    children: [
      { path: "Trainee", component: ViewTraineeforRvsRgstrComponent },
      { path: "GovernmentalEntities", component: GovernmentalEntitiesComponent },
      { path: "AddCourses", component: MangeCourseComponent },
      { path: "GetCoursesById/:id", component: MangeCourseComponent},
      { path: "EditCourses/:id", component: MangeCourseComponent },
      { path: "ViewCourses", component: ViewCoursesComponent },
    ]
  },


];





@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})


export class RvRgstrRoutingModule { }
