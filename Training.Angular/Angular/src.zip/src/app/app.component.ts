import { TranslateService } from '@ngx-translate/core';
import { SharedService } from './Services/Shared/shared.service';
import { Component, ElementRef, OnInit } from '@angular/core';
import { PrimeNGConfig } from 'primeng/api';
import 'jquery';
import * as $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent implements OnInit {
  title = 'app';
  currentLang: string;

  constructor(private elRef: ElementRef,
    private primengConfig: PrimeNGConfig,
    public translate: TranslateService,
    public shared: SharedService) {

    shared.setDefaultLang();

  }

  ngOnInit() {
    this.primengConfig.ripple = true;
  }


}
