import { Injectable } from '@angular/core';
import { baseService } from 'src/app/Services/Shared/baseService.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';

import { LookupDto } from 'src/app/models/Common/WorkPlaceDTO';
import { ReviewCityDTO } from '../../models/City/ReviewCityDTO';
import { ReviewCityFilter } from '../../models/City/ReviewCityFilter';
@Injectable({
  providedIn: 'root'
})

export class CityService extends baseService<ReviewCityDTO, number, ReviewCityFilter>{

  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Cities/`}`);
  }

    GetCities(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetCities'}`);
  }
}
