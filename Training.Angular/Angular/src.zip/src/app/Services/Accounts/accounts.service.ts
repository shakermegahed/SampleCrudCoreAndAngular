import { Injectable } from '@angular/core';
import { baseService } from 'src/app/Services/Shared/baseService.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';

import { ReviewUsersDTO } from 'src/app/models/Admin/ReviewUsersDTO';
import { ReviewUsersFilter } from 'src/app/models/Admin/ReviewUsersFilter';
import { LookupDto } from 'src/app/models/Common/WorkPlaceDTO';

@Injectable({
  providedIn: 'root'
})
export class AccountsService extends baseService<ReviewUsersDTO, number, ReviewUsersFilter> {

  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Accounts/`}`);
  }


  RegisterationByAdmin(model: ReviewUsersDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'RegisterationByAdmin'}`, model)
  };

  GetRoles(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetRoles'}`);
  }

}
