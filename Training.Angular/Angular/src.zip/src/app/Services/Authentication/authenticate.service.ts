import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserDTO } from 'src/app/models/Authentication/UserDTO';
import { LoginDTO } from 'src/app/models/Authentication/LoginDTO';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor(private httpclient:HttpClient) {
   }
   baseUrl = environment.baseUrl;

    AuthenticateUser(loginModel:LoginDTO): Observable<UserDTO> {
      return this.httpclient.post<UserDTO>(this.baseUrl + 'Accounts/Login',loginModel)
    }
    // this.httpclient.get("https://jsonplaceholder.typicode.com/posts");
   }
