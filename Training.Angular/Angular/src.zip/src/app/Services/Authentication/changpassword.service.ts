import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ChangpasswordDTO } from 'src/app/models/Authentication/ChangpasswordDTO';
import { FilterModel } from 'src/app/models/Common/FilterModel';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';
import { environment } from 'src/environments/environment';
import { baseService } from '../Shared/baseService.service';

@Injectable({
  providedIn: 'root'
})
export class ChangpasswordService  extends baseService<ChangpasswordDTO, number, FilterModel> {

  // tslint:disable-next-line: variable-name
  constructor(protected _http: HttpClient) {
   super(_http, `${environment.baseUrl}${`Accounts/`}`);
 }



 ChangePasswordFirstTime(Token,Password): Observable<ResultSaveDTO> {
  // console.log(`hi you are now in way to Delete for ${this.myURL}`);
  return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'ChangePasswordFirstTime'}?Token=${Token}&Password=${Password}`,null)
};

}
