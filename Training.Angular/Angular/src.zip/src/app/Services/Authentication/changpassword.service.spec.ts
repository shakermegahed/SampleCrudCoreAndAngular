import { TestBed } from '@angular/core/testing';

import { ChangpasswordService } from './changpassword.service';

describe('ChangpasswordService', () => {
  let service: ChangpasswordService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChangpasswordService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
