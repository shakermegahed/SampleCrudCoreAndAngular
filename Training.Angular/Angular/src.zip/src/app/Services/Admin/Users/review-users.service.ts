import { ResultDeleteDTO } from './../../../models/Common/ResultDeleteDTO';
import { DeleteTrainee } from './../../../models/Admin/DeleteTrainee';
import { Injectable } from '@angular/core';
import { baseService } from 'src/app/Services/Shared/baseService.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';

import { ReviewUsersDTO } from 'src/app/models/Admin/ReviewUsersDTO';
import { ReviewUsersFilter } from 'src/app/models/Admin/ReviewUsersFilter';
import { User } from 'src/app/models/Admin/User';
import { UserActivateDeatcivate } from 'src/app/models/Admin/UserActivateDeatcivate';

@Injectable({
  providedIn: 'root'
})
export class ReviewUsersService extends baseService<ReviewUsersDTO, number, ReviewUsersFilter> {

  // tslint:disable-next-line: variable-name
  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Users/`}`);
  }

  GetUsers(filter: ReviewUsersFilter): Observable<IResultForDatatTableDTO<ReviewUsersDTO>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<ReviewUsersDTO>>(`${this.myURL}${'GetUsers'}`, filter);
  }

  GetUsersById(UserId): Observable<User> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<User>(`${this.myURL}${'GetUserById'}?UserId=${UserId}`);
  }

  UpdateUser(model: ReviewUsersDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'UpdateUser'}`, model)
  };

  DeleteUnDeleteTraniee(model: DeleteTrainee): Observable<ResultDeleteDTO> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<ResultDeleteDTO>(`${this.myURL}DeleteUnDeleteUser?Id=${model.TranieeId}&IsDeleted=${model.IsDeleted}`, null);
  }

  GetUserStatus(Id: string): Observable<ReviewUsersDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.get<ReviewUsersDTO>(`${this.myURL}${'GetUserStatus'}?UserId=${Id}`)
  };
  ActiveUser(model: UserActivateDeatcivate): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
      return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'ActiveDeactiveUser'}`, model)
  };
}
