import { ResultSaveGeneric } from 'src/app/models/Common/ResultSaveGeneric';
import { ResultDeleteDTO } from './../../models/Common/ResultDeleteDTO';
import { DeleteTrainee } from './../../models/Admin/DeleteTrainee';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ReviewTraineesDTO } from 'src/app/models/Admin/ReviewTraineesDTO';
import { ReviewTraineesFilter } from 'src/app/models/Admin/ReviewTraineesFilter';
import { FilterModel } from 'src/app/models/Common/FilterModel';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';
import { environment } from 'src/environments/environment';
import { baseService } from '../Shared/baseService.service';
import { TraineeActivateDeatcivate } from 'src/app/models/Admin/TraineeActivateDeatcivate';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';
import { LookupDto } from 'src/app/models/Common/WorkPlaceDTO';

@Injectable({
  providedIn: 'root'
})
export class ReviewTraineesService extends baseService<ReviewTraineesDTO, number, ReviewTraineesFilter> {

  // tslint:disable-next-line: variable-name
  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Traniee/`}`);
  }

  GetTrainees(filter: ReviewTraineesFilter): Observable<IResultForDatatTableDTO<ReviewTraineesDTO>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<ReviewTraineesDTO>>(`${this.myURL}${'GetTrainees'}`, filter);
  }

  GetWorkPlaces(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetWorkPlaces'}`);
  }
  GetTraineesTitles(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetTraineesTitles'}`);
  }

  AddTraniee(model: ReviewTraineesDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'AddTraniee'}`, model)
  };

  DeleteUnDeleteTraniee(model: DeleteTrainee): Observable<ResultDeleteDTO> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<ResultDeleteDTO>(`${this.myURL}DeleteUnDeleteTraniee?TranieeId=${model.TranieeId}&IsDeleted=${model.IsDeleted}`, null);
  }

  GetTranieeById(TranieeId): Observable<ReviewTraineesDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.get<ReviewTraineesDTO>(`${this.myURL}${'GetTranieeById'}?TranieeId=${TranieeId}`)
  };
  GetTranieeStatus(TranieeId: number): Observable<ReviewTraineesDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.get<ReviewTraineesDTO>(`${this.myURL}${'GetTranieeStatus'}?TranieeId=${TranieeId}`)
  };

  UpdateTraniee(model: ReviewTraineesDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'UpdateTraniee'}`, model)
  };
  ActiveTraniee(model: TraineeActivateDeatcivate): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'ActiveTraniee'}`, model)
  };

}