import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';
import { ResultDeleteDTO } from 'src/app/models/Common/ResultDeleteDTO';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';
import { GovernmentalFilter } from 'src/app/models/RevisionRegister/Governmental/GovernmentalFilter';
import { GovernmentalDTO } from 'src/app/models/RevisionRegister/Governmental/GovernmentalDTO';


import { environment } from 'src/environments/environment';
import { baseService } from '../../Shared/baseService.service';
import { DeleteGovernmentDTO } from 'src/app/models/RevisionRegister/Governmental/DeleteGovernmentDTO';

@Injectable({
  providedIn: 'root'
})



export class GovernmentaService extends baseService<GovernmentalDTO, number, GovernmentalFilter> {

  // tslint:disable-next-line: variable-name
  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Governmental/`}`);
  }


  Addgovernment(model: GovernmentalDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'Addgovernment'}`, model)
  };

  Importgovernment(formData: FormData): Observable<IResultForDatatTableDTO<GovernmentalDTO>> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<GovernmentalDTO>>(`${this.myURL}${'ImportGovernment'}`, formData)
  };

  GetGovernmentById(id): Observable<GovernmentalDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.get<GovernmentalDTO>(`${this.myURL}${'GetGovernmentById'}?id=${id}`)
  };

  GetGovernments(filter: GovernmentalFilter): Observable<IResultForDatatTableDTO<GovernmentalDTO>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<GovernmentalDTO>>(`${this.myURL}${'GetGovernments'}`, filter);
  }

  UpdateGovernment(model: GovernmentalDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'UpdateGovernment'}`, model)
  };

  UpdateGovernmentName(model: GovernmentalDTO[]): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'UpdateGovernmentName'}`, model)
  };

  DeleteGovernment(model: DeleteGovernmentDTO): Observable<ResultDeleteDTO> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<ResultDeleteDTO>(`${this.myURL}DeleteGovernment?GovernmentId=${model.GovernmentId}&IsDeleted=${model.IsDeleted}`, null);
  }

  ActiveGovernment(model: GovernmentalDTO): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'ActiveGovernment'}`, model)
  };

}


