import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class RevisionRegisterService {
baseUrl: any = "https://jsonplaceholder.typicode.com";
  

  constructor(public httpclient : HttpClient) { }

  deleteItem(id :number){
    return this.httpclient.delete(` ${this.baseUrl}/todos/${id}`)
  }
  

}
