import { DeleteCancelCourse } from './../../models/Courses/DeleteCancelCourse';
import { ResultList } from './../../models/Common/ResultList';
import { Injectable } from '@angular/core';
import { baseService } from 'src/app/Services/Shared/baseService.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';
import { ResultSaveDTO } from 'src/app/models/Common/ResultSaveDTO';

import { ReviewCourseDTO } from 'src/app/models/Courses/ReviewCoursesDTO';
import { ReviewCoursesFilter } from 'src/app/models/Courses/ReviewCoursesFilter';
import { LookupDto } from 'src/app/models/Common/WorkPlaceDTO';
import { Course } from '../../models/Courses/Course';

@Injectable({
  providedIn: 'root'
})
export class ReviewCoursesService extends baseService<Course, number, ReviewCoursesFilter> {

  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Courses/`}`);
  }

  GetCourseTypes(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetCourseTypes'}`);
  }

  GetCourseStatus(): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetCourseStatus'}`);
  }

  AddCourse(model: Course): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'AddCourse'}`, model)
  };
  GetCourses(filter: ReviewCoursesFilter): Observable<IResultForDatatTableDTO<Course>> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<Course>>(`${this.myURL}${'GetCourses'}`, filter)
  };

  GetCourseById(CourseId): Observable<Course> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.get<Course>(`${this.myURL}${'GetCourseById'}?CourseId=${CourseId}`);
  }

  UpdateCourse(model: Course): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'UpdateCourse'}`, model)
  };

  CancelCourse(model: DeleteCancelCourse): Observable<ResultSaveDTO> {
    // console.log(`hi you are now in way to Delete for ${this.myURL}`);
    return this.httpClient.post<ResultSaveDTO>(`${this.myURL}${'CancelCourse'}`, model)
  };

}
