import { Injectable } from '@angular/core';
import { baseService } from 'src/app/Services/Shared/baseService.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IResultForDatatTableDTO } from 'src/app/models/Common/IResultForDatatTableDTO';

import { ReviewTrainerDTO } from 'src/app/models/Trainer/ReviewTrainerDTO';
import { ReviewTrainerFilter } from 'src/app/models/Trainer/ReviewTrainerFilter';
import { LookupDto } from 'src/app/models/Common/WorkPlaceDTO';
@Injectable({
  providedIn: 'root'
})
export class TrainerService extends baseService<ReviewTrainerDTO, number, ReviewTrainerFilter> {

  constructor(protected _http: HttpClient) {
    super(_http, `${environment.baseUrl}${`Trainer/`}`);
  }

  GetTrainers(filter: ReviewTrainerFilter): Observable<IResultForDatatTableDTO<LookupDto>> {
    console.log(`hi you are now in way to GetAll for ${this.myURL}`);
    return this.httpClient.post<IResultForDatatTableDTO<LookupDto>>(`${this.myURL}${'GetTrainers'}`, filter);
  }
}
