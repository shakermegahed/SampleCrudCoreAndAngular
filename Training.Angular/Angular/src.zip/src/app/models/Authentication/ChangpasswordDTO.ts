export interface ChangpasswordDTO{
    Token:string;
    Password:string;
 }
 