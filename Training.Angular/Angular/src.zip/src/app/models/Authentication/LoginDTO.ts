export class LoginDTO{
   UserName:string;
   Password:string;
}
