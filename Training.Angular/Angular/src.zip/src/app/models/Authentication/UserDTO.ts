import { ResultSaveDTO } from "../Common/ResultSaveDTO";

export interface UserDTO extends ResultSaveDTO {
	token: string;
	name: string;
	dbUserId: string;
	userName: string;
	email: string;
	message: string;
	userRoles: string[];
   succeeded: boolean;
   password:string;
}
