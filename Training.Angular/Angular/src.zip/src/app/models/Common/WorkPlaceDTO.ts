export interface LookupDto {
  id:number;
  name:string;
}
