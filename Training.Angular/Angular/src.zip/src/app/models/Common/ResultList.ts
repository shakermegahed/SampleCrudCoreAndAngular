import { ResultPage } from "./ResultPage";

export class ResultList<T>{
    List: T[] ;
    ResultPaging:ResultPage;
}
