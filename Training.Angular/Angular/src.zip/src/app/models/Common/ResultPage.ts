export class ResultPage{
  // tslint:disable-next-line: no-inferrable-types
  Pagelength: number = 0;
  // tslint:disable-next-line: no-inferrable-types
  RecordsTotal: number = 0;
  // tslint:disable-next-line: no-inferrable-types
  RecordsFiltered: number = 0;
}
