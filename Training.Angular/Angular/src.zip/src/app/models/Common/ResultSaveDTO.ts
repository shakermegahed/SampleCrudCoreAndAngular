export class ResultSaveDTO {
    success: boolean = false;
    message: string = '';
}
