export interface IResultPaging {
    pagelength: number;
    recordsTotal: number;
    recordsFiltered: number;
}
