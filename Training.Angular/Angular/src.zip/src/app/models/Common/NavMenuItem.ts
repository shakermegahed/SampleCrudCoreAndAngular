export class NavMenu{
  path:string = "";
  icon: string ="";
  linkTitle:string = "" ;
  childMenu: NavMenu[]=[];
}
