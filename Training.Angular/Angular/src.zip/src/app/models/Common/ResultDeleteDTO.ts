export class ResultDeleteDTO {
    success: boolean = false;
    message: string = '';
}
