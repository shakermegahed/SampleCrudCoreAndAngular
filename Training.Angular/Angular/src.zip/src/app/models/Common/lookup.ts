export class Lookup{
  Id = 0;
  // tslint:disable-next-line: no-inferrable-types
  Name: string ="";
  // tslint:disable-next-line: no-inferrable-types
  NameAr: string = "";
  // tslint:disable-next-line: no-inferrable-types
  NameEn:string = "" ;
}
