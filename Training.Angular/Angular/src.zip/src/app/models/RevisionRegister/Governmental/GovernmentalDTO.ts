export class GovernmentalDTO {

       
    governmentalId: number;
    governmentalName: string;
    email: string;
    address: string;
    phone: string;
    mobile: string;
    status: boolean;
    code: string;
    allowTrainee: boolean;
    contacted: boolean;
    responsible:string;




}


