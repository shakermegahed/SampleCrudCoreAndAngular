

export interface DeleteGovernmentDTO {
    GovernmentId:number;
    IsDeleted:boolean;
}