export interface ReviewCityDTO {

}
