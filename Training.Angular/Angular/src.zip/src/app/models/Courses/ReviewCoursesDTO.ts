export interface ReviewCourseDTO {

}
