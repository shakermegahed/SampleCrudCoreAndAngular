import { CourseExtraSetting } from "./CourseExtraSetting";

export class CourseExtraSettingImplement implements CourseExtraSetting {
  courseId: number;
  schoolCertificate: Boolean;
  jobDescription: Boolean;
  saudiPostalCode: Boolean;
  buildingNumber: Boolean;
  streetNumber: Boolean;
  postalCode: Boolean;
  extraCode: Boolean;
  fillExcelForProfessionalCourse: Boolean;
  fillWordForProfessionalCourse: Boolean;
  fillEnergyForm: Boolean;
  approvalLetter: Boolean;
  canLeave: Boolean;
  canChangeDate: Boolean;
  canLeaveAndMoneyBack: Boolean;
  canRedoTest: Boolean;
  canChangeTestDate: Boolean;
  canRegisterInWaitingList: Boolean;
  hasCourseCertificate: Boolean;
  isExtraCourse: Boolean;

}
