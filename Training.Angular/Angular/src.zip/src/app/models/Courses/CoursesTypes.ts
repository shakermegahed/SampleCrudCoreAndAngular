export interface CoursesTypes {
  id: number,
  name:string
}
