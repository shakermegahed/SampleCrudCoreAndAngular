import { CourseExtraSetting } from "./CourseExtraSetting";

export interface Course {
  number: string,
  courseName: string,
  courseTypeId: number,
  courseStatusId: number,
  startDate: string,
  endDate: string,
  cityId: number,
  isFree: Boolean,
  fees: number,
  trainerId: number,
  address: string,
  avaliableSeats: number,
  numberWaitingSeats: number,
  numberOfDays: number,
  isEvaluationEnabled: Boolean,
  highestScore: number,
  minimumSuccessScore: number,
  miminumAttendance: number,
  dates: Date[],
  extraSetting: CourseExtraSetting;
  id: number;
  hasCourseCertificate: Boolean;
  isExtraCourse: Boolean;
}
