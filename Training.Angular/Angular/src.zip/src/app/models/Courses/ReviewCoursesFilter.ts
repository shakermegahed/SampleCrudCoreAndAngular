import { FilterModel } from "../Common/FilterModel"

export class ReviewCoursesFilter extends FilterModel {
  orderBy: string;
  
  Year: number;
  CourseTypeId: number;
  CourseStatusId: number;
  CourseNameAr: number;
  CourseNameEn: number;
}
