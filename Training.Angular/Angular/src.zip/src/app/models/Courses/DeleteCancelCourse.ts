export interface DeleteCancelCourse {
    courseId:number;
    IsDeleted:boolean;
    reason:string;
}
