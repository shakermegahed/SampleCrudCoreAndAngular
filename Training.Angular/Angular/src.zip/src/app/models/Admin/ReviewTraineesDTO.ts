export interface ReviewTraineesDTO {

  tranieeId: number;
//remove
  fullName: string;

  firstName: string,
  secondName: string,
  thirdName: string,
  lastName: string,

  email: string;
  gender: number;
  birthDate: Date;
  status: boolean;
  statusName: string;
  genderName: string;
  ssNumber: string,
  department: string;
  workplaceType: string;
  workplaceId: number;
  workPlaceText: number;
  phoneNumber: string;
  titleId: number;
  isDeleted: boolean;
  deletedName: string;
  userName: string;
}












