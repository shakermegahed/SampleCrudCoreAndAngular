import { FilterModel } from "../Common/FilterModel"

 export class ReviewTraineesFilter extends FilterModel{
    orderBy: string;
    fullName: string;
    email: string;
    ssNumber: string
 }