export interface UserActivateDeatcivate {
  userId:number;
  status:boolean;
  reason:string;
}
