export interface DeleteTrainee {
    TranieeId:any;
    IsDeleted:boolean;
}
