export interface TraineeActivateDeatcivate {
  tranieeId:number;
  status:boolean;
  reason:string;
}
