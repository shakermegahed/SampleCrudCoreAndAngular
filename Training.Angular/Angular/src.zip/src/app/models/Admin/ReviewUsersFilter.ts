import { FilterModel } from "../Common/FilterModel"

export class ReviewUsersFilter extends FilterModel {
  orderBy: string;
  fullName: string;
  email: string;
  ssNumber: string
}
