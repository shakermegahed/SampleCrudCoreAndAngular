export interface ReviewUsersDTO {
  userId: string;
  firstName:string;
  secondName:string;
  thirdName:string;
  lastName:string;
  status: boolean;

}
