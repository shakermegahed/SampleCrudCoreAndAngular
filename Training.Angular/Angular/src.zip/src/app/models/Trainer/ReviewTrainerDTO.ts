export interface ReviewTrainerDTO {

}
