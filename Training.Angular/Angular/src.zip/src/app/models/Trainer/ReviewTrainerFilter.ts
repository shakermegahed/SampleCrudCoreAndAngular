import { FilterModel } from "../Common/FilterModel"

export class ReviewTrainerFilter extends FilterModel {
  orderBy: string;
  
    name: string;
    constructor() {
      super();
    }
}
