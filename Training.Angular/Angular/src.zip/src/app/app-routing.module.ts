import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { TranslateModule } from "@ngx-translate/core";
import { HomeComponent } from "./components/home/home.component";
import { AuthGuard } from "./modules/Authentication/auth.guard";
import { AuthenticationComponent } from "./modules/Authentication/Authentication.component";
import { LogInComponent } from "./modules/Authentication/LogIn/LogIn.component";
import { Error404Component } from "./modules/shared/error404/error404.component";
import { TestComponent } from "./modules/shared/test/test.component";

const routes: Routes = [
	{
		path: "",
		component: HomeComponent,

	},
	{
		path: "Authentication",
		component: AuthenticationComponent,
		children: [
			{
				path: "",
				 loadChildren: () => import("./modules/Authentication/auth.module").then((m) => m.AuthModule),
			}
    ],
    canActivate:[AuthGuard]
	},
	{
		path: "admin",
		loadChildren: () => import("./modules/Admin/admin.module").then((admin) => admin.AdminModule)
	},
	{
		path: "rvrgstr",
		loadChildren: () => import("./modules/RevisionRegister/RvRgstr.module").then((admin) => admin.RvRgstrModule)
	},
	{
		path: '**',
		component: Error404Component,
	}
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule, TranslateModule],
})
export class AppRoutingModule { }
