$(function() {

    sidebarToggle();

    $('.sidebartoggler').on('click', function() {
        $('#main-wrapper').toggleClass('mini-sidebar');
        if ($('#main-wrapper').hasClass('mini-sidebar')) {
            $('#main-wrapper').attr('data-sidebartype', 'mini-sidebar')
        } else {

            $('#main-wrapper').attr('data-sidebartype', 'full')
        }
    })


    $(".left-sidebar").hover(
        function() {
            $(".navbar-header").addClass("expand-logo");
        },
        function() {
            $(".navbar-header").removeClass("expand-logo");
        }
    );
    // this is for close icon when navigation open in mobile view
    $(".nav-toggler").on('click', function() {
        $('#main-wrapper').toggleClass('mini-sidebar');
        $("#main-wrapper").toggleClass("show-sidebar");
        $(".nav-toggler i").toggleClass("ti-menu");
    });
    $(".nav-lock").on('click', function() {
        $("body").toggleClass("lock-nav");
        $(".nav-lock i").toggleClass("mdi-toggle-switch-off");
        $("body, .page-wrapper").trigger("resize");
    });
    $(".search-box a, .search-box .app-search .srh-btn").on('click', function() {
        $(".app-search").toggle(200);
        $(".app-search input").focus();
    });

    $(window).on('resize', function() {
        sidebarToggle();
    })

})

function sidebarToggle() {

    if ($(window).width() < 1169) {
        $('#main-wrapper').attr("data-sidebartype", "mini-sidebar").toggleClass("mini-sidebar")
    } else {
        $('#main-wrapper').attr("data-sidebartype", "full").toggleClass("mini-sidebar")

    }
}