// Admin Panel settings
$.fn.AdminSettings = function(settings) {
    var myid = this.attr("id");
    // General option for vertical header 
    var defaults = {
        Theme: false, // this can be true or false ( true means dark and false means light ),
        Layout: 'vertical',
        LogoBg: 'skin5', // You can change the Value to be skin1/skin2/skin3/skin4/skin5/skin6 
        NavbarBg: 'skin5', // You can change the Value to be skin1/skin2/skin3/skin4/skin5/skin6
        SidebarType: 'full', // You can change it full / mini-sidebar / iconbar / overlay
        SidebarColor: 'skin5', // You can change the Value to be skin1/skin2/skin3/skin4/skin5/skin6
        SidebarPosition: true, // it can be true / false ( true means Fixed and false means absolute )
        HeaderPosition: true, // it can be true / false ( true means Fixed and false means absolute )
        BoxedLayout: false, // it can be true / false ( true means Boxed and false means Fluid ) 
    };
    var settings = $.extend({}, defaults, settings);
    // Attribute functions 
    var AdminSettings = {
        // Settings INIT
        AdminSettingsInit: function() {
            AdminSettings.ManageTheme();
            AdminSettings.ManageThemeLayout();
            AdminSettings.ManageThemeBackground();
            AdminSettings.ManageSidebarType();
            AdminSettings.ManageSidebarColor();
            AdminSettings.ManageSidebarPosition();
            AdminSettings.ManageBoxedLayout();
        },
        //****************************
        // ManageThemeLayout functions
        //****************************
        ManageTheme: function() {
            var themeview = settings.Theme;
            switch (settings.Layout) {
                case 'vertical':
                    if (themeview == true) {
                        $('body').attr("data-theme", 'dark');
                        $("#theme-view").prop("checked", !0);
                    } else {
                        $('#' + myid).attr("data-theme", 'light');
                        $("body").prop("checked", !1);
                    }
                    break;

                default:
            }
        },
        //****************************
        // ManageThemeLayout functions
        //****************************
        ManageThemeLayout: function() {
            switch (settings.Layout) {
                case 'horizontal':
                    $('#' + myid).attr("data-layout", "horizontal");
                    break;
                case 'vertical':
                    $('#' + myid).attr("data-layout", "vertical");
                    $('.scroll-sidebar').perfectScrollbar({});
                    break;
                default:
            }
        },

        //****************************
        // ManageSidebarType functions 
        //****************************
        ManageThemeBackground: function() {
            // Logo bg attribute
            function setlogobg() {
                var lbg = settings.LogoBg;
                $('#' + myid + ' .topbar .top-navbar .navbar-header').attr("data-logobg", lbg);
            };
            setlogobg();
            // Navbar bg attribute
            function setnavbarbg() {
                var nbg = settings.NavbarBg;
                $('#' + myid + ' .topbar .navbar-collapse').attr("data-navbarbg", nbg);
                $('#' + myid + ' .topbar').attr("data-navbarbg", nbg);
                $('#' + myid).attr("data-navbarbg", nbg);
            };
            setnavbarbg();
        },

        //****************************
        // ManageSidebarColor functions 
        //****************************
        ManageSidebarColor: function() {
            // Logo bg attribute
            function setsidebarbg() {
                var sbg = settings.SidebarColor;
                $('#' + myid + ' .left-sidebar').attr("data-sidebarbg", sbg);
            };
            setsidebarbg();
        },
    }
}